//
//  IGSparklineView.h
//  IGChart
//
//  Created by Darrell Kress on 4/1/13.
//
//

#import <UIKit/UIKit.h>

@class IGSparklineView;

@protocol IGSparklineViewDelegate <NSObject>

@optional
/** Provides a custom view to be used as a tooltip in the chart view.
 @param chartView Reference to the IGSparklineView.
 @param itemList A dictionary of series and data points that can be displayed in the tooltip.
 @return UIView that will be used as a tooltip.
 */
-(UIView*)sparklineView:(IGSparklineView*)sparklineView viewForTooltipWithItemlist:(NSDictionary*)itemlist;

/** Provides a custom view to be used as a tooltip in the chart view.
 @param chartView Reference to the IGSparklineView.
 @param itemList A dictionary of series and data points that can be displayed in the tooltip.
 @param point Coordinates of the touch point.
 @return UIView that will be used as a tooltip.
 */
-(UIView*)sparklineView:(IGSparklineView*)sparklineView viewForTooltipWithItemlist:(NSDictionary*)itemlist atPoint:(CGPoint)point;


@end


/*! IGSparklineViewDataSource protocol represents the data model object used by the Sparkline chart. It provides the means to supply the sparkline chart with data.
 This protocol can be implemented by the user to provide full control over the data that goes into the sparkline chart. Alternatively, IGSparklineViewDataSource can be used to simply that process.
 */
@protocol IGSparklineViewDataSource <NSObject>
@required
/** This method specifies the number of data items in the sparkline chart.
 @param sparklineView Reference to the sparkline chart.
 @return Returns the number of data items in the sparkline chart.
 */
-(NSInteger)numberOfPointsInSparklineView:(IGSparklineView*)sparklineView;

/** This method supplies an IGDataPoint reference to the pie chart at a given index.
 @param sparklineView Reference to the sparkline chart.
 @param index The current index.
 @return Returns an initialized IGDataPoint to be used by the sparkline chart.
 */
-(IGDataPoint*)sparkLineChartView:(IGSparklineView*)sparklineView pointAtIndex:(NSInteger)index;
@optional
/** This method can be used to supply the sparkline chart with a range of data points. If this method is implemented the datasource will not respond to numberOfPointsInSparklineChartView or pointAtIndex.
 @param sparklineView Reference to the pie chart.
 @return Returns a range of initialized points.
 */
-(NSArray*)allPointsForSeries:(IGSparklineView*)sparklineView;
@end


/*! This data source helper is used to create a data source for the pie chart.
 The data source helper provides a simplified way of supplying data for the pie chart. The resulting data structure contains multiple IGCategoryPoint instances.
 */
@interface IGSparklineViewDataSourceHelper : NSObject<IGSparklineViewDataSource>

/** An array of custom data objects. The fields in the data object are accessed via memberPath properties.
 */
@property (nonatomic, retain) NSArray* data;

/** An array of string labels used to create data points.
 */
@property (nonatomic, retain) NSArray* labels;

/** Name of the property containing labels.
 */
@property (nonatomic, retain) NSString* labelPath;

/** A numeric array of values used to create data points.
 */
@property (nonatomic, retain) NSArray* values;

/** A string value path that specifies the property in the data source used for values.
 */
@property (nonatomic, retain) NSString *valuePath;

///--------------------
///@name Initializing DataSource Helper
///--------------------

/** Initializes the data source with an array of numeric values.
 @param values Array of numeric values.
 @return Returns an initialized data source.
 */
-(id)initWithValues:(NSArray*)values;

/** Initializes the data source with an array of numeric values and string labels.
 @param values Array of numeric values.
 @param labels Array of string labels.
 @return Returns an initialized data source.
 */
-(id)initWithValues:(NSArray*)values labels:(NSArray*)labels;

/** Initializes the data source with an array of custom data objects.
 @param data Array of custom objects.
 @param valuePath The name of the property containing values.
 @return Returns an initialized data source.
 */
-(id)initWithData:(NSArray*)data valuePath:(NSString*)valuePath;

/** Initializes the data source with an array of custom data objects.
 @param data Array of custom objects.
 @param valuePath The name of the property containing values.
 @param labelPath The name of the property containing labels.
 @return Returns an initialized data source.
 */
-(id)initWithData:(NSArray*)data valuePath:(NSString*)valuePath labelPath:(NSString*)labelPath;
@end


/*!
 The xamSparkline™ is a lightweight charting control that can render the following chart types:
 
 Line
 Area
 Column
 Win/Loss
 It is intended for rendering in a small scale layout such as a grid Cell. It can also be rendered stand alone. 
 */
@interface IGSparklineView : UIView

/** Sets the data source for the pie chart view. This can be an interface that conforms to IGSparklineViewDataSource protocol or an instance of IGSparklineViewDataSourceHelper.
 */
@property (nonatomic, assign) id<IGSparklineViewDataSource> dataSource;

/** Returns an array of IGCategoryPoint objects. (read-only)
 */
@property (nonatomic, readonly) NSMutableArray *dataPoints;

/*! The IGBrush which all will be used for positive values */
@property (nonatomic, retain) IGBrush *brush;

/*! The IGBrush which will be used when rendering negative values. */
@property (nonatomic, retain) IGBrush *negativeBrush;

/*! The IGBrush which will be used for positive value markers. */
@property (nonatomic, retain) IGBrush *markerBrush;

/* The IGBrush which will be used for negative value markers. */
@property (nonatomic, retain) IGBrush *negativeMarkerBrush;

/* The IGBrush which will be used for the first rendered marker. */
@property (nonatomic, retain) IGBrush *firstMarkerBrush;

/* The IGBrush which will be used for the last rendered marker.*/
@property (nonatomic, retain) IGBrush *lastMarkerBrush;

/* The IGBrush which will be used for the highest value marker rendered. */
@property (nonatomic, retain) IGBrush *highMarkerBrush;

/* The IGBrush which will be used for the lowest value marker rendered. */
@property (nonatomic, retain) IGBrush *lowMarkerBrush;

/* The IGBrush which will be used for the trendline. */
@property (nonatomic, retain) IGBrush *trendLineBrush;

/* The IGBrush which will be used for the horizontal axis lines. */
@property (nonatomic, retain) IGBrush *horizontalAxisBrush;

/* The IGBrush which will be used for the vertical axis lines. */
@property (nonatomic, retain) IGBrush *verticalAxisBrush;

/* The IGBrush which will be used for the normal range. */
@property (nonatomic,retain) IGBrush *normalRangeBrush;

/*
 Visibility setting allows displaying the horizontal line of X axis.
 
 Only the minimum and maximum values per axis will display, because of the size limitation of the Sparkline.
 */
@property (nonatomic) BOOL horizontalAxisVisibility;

/*
 Visibility setting allows displaying the vertical line of X axis.
 */
@property (nonatomic) BOOL verticalAxisVisibility;

/*
Determines if markers will visible on the sparkline.
*/
@property (nonatomic) BOOL markerVisibility;

/*
 Determines if markers will be visible for negative values on the sparkline.
 */
@property (nonatomic) BOOL negativeMarkerVisibility;

/*
 Determines if markers will be visible on the first value of the sparkline.
 */
@property (nonatomic) BOOL firstMarkerVisibility;

/*
Determines if markers will be visible on the last value of the sparkline.
 */
@property (nonatomic) BOOL lastMarkerVisibility;

/*
 Determines if markers will be visibile on the lowest value of the sparkline.
 */
@property (nonatomic) BOOL lowMarkerVisibility;
/*
 Determines if markers will be visibile on the highest value of the sparkline.
 */
@property (nonatomic) BOOL highMarkerVisibility;
/*
 Determines if markers will be visibile normal range of the sparkline.
 */
@property (nonatomic) BOOL normalRangeVisibility;

/**
 Determines if the normal range is displayed in front or behind the sparkline points.
 */
@property (nonatomic) BOOL displayNormalRangeInFront;

/*
 Specifies that size of the marker on the first data point.
 */
@property (nonatomic) double firstMarkerSize;

/*
 Specifies that size of the marker on the last data point.
 */
@property (nonatomic) double lastMarkerSize;

/*
 Specifies that size of the marker on the hightest data point.
 */
@property (nonatomic) double highMarkerSize;

/*
 Specifies that size of the marker on the lowest data point.
 */
@property (nonatomic) double lowMarkerSize;

/*
 Specifies the default marker size.
 */
@property (nonatomic) double markerSize;

/*
 Specifies the default marker size for values that are negative.
 */
@property (nonatomic) double negativeMarkerSize;

/*
 When then displayType is set to line, this property is used for the thickness of the rendered line.
 */
@property (nonatomic) double lineThickness;

/*
 The minimum value that will be displayed on the sparkline.
 */
@property (nonatomic) double minimum;
/*
 The maximum value that will be displayed on the sparkline.
 */
@property (nonatomic) double maximum;

/** An enumeration property that determines which trend line to use.
 */
@property (nonatomic) IGTrendLineType trendLineType;

/** A value that determines the moving average period.
 This property only applies to the follwing trend lines: ExponentialAverage, ModifiedAverage, SimpleAverage, WeightedAverage.
 */
@property (nonatomic) NSInteger trendLinePeriod;

/** A value that determines the thickness of the trend line.
 */
@property (nonatomic) double trendLineThickness;
/*
Specifies the lower boarder of the Normal Range.
*/
@property (nonatomic) double normalRangeMinimum;
/*
 Specifies the higher boarder of the Normal Range.
 */
@property (nonatomic) double normalRangeMaximum;

/** 
 Used to determine the type of Sparkline.
 
 The valid setting are:
 
 IGSparklineDisplayTypeLine – Displays line type of chart
 IGSparklineDisplayTypeArea – Displays area type of chart
 IGSparklineDisplayTypeColumn – Displays column type of chart, same as vertical bars
 IGSparklineDisplayTypeWinLoss – Displays a chart visualizing Win or Loss scenario based on positive and negative values
 
 */
@property (nonatomic) IGSparklineDisplayType displayType;

/** An enumeration value that determines how empty values are handled.
 This property specifies whether null values are treated as zeroes, skipped over or if an interpolation is used.
 */
@property (nonatomic)IGUnknownValuePlotting unknownValuePlotting;

/** An object that defines a set of brushes and fonts that will be used to style the sparkline.
 */
@property (nonatomic, retain) id<IGSparklineThemeDefinition> theme;

/*
 Allows formatting the labels on horizontal (X) axis.
 */
@property(nonatomic,retain) NSObject* horizontalAxisLabel;

/** Specifies the tooltip location.
 
 This property determines where the tooltip will be positioned. The default setting uses a floating tooltip, which follows the location of the long press. Tooltip can also be pinned to top, bottom, left, or right.
 */
@property (nonatomic) IGTooltipPinLocation tooltipPinLocation;


/** Sets the IGChartViewDelegate for the chart view
 */
@property (nonatomic, assign) id<IGSparklineViewDelegate> delegate;

/** The font that will be applied to the text of the sparkline
 */
@property (nonatomic, assign) UIFont* font;

/*
 The brush that will be used with any text on the control.
 */
@property (nonatomic, retain) IGBrush* fontBrush;

-(VisualSparklineVisualData*)exportVisualData;


@end
