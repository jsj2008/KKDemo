#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "IGTreemapThemeDefinition.h"
#import "Core.h"

@interface IGTreemapViewTheme1 : NSObject <IGTreemapThemeDefinition>
@end

@interface IGTreemapViewTheme2 : NSObject <IGTreemapThemeDefinition>
@end

@interface IGTreemapViewTheme3 : NSObject <IGTreemapThemeDefinition>
@end

@interface IGTreemapViewTheme4 : NSObject <IGTreemapThemeDefinition>
@end

@interface IGTreemapViewTheme5 : NSObject <IGTreemapThemeDefinition>
@end