//
//  IGRangeSelectorView.h
//  IGChart
//
//  Created by Darrell Kress on 8/20/13.
//
//

#import <UIKit/UIKit.h>
#import "IGChartView.h"

@interface IGRangeSelectorThumbView : UIView
@property (retain,nonatomic) UIColor* hashMarkColor;
@end

/*  The IGRangeSelectorView control is used with the IGChartView to control zooming and scrolling when the IGChartView's zoomDisplayType is set to horizontal or vertical.
 */
@interface IGRangeSelectorView : UIView

/* This is the UIView which will provide the background scale for the range selector.  This will be a mini representation of the data in the attached chart.
 */
@property (assign)UIView* contentView;

/*
 Gets or sets the color which will be applied to the area of range selector which represents data not shown in the main view.  
 */
@property (retain)UIColor* shadeColor;
/*
 Gets or sets the size for the minimum and maximum thumbs.
 */
@property (assign)double minMaxThumbSize;
/*
 Gets or sets the UIView which will be used as part of the center eye.  The thumb is area between the minimum and maximum thumbs which indicates what area of the attached IGChartView is zoomed.
 */
@property (retain)UIView* thumbView;
/* 
    Gets or sets the UIView which will be used inside the maximum thumb.
 */
@property (retain)UIView* minimumThumbView;
/*
 Gets or sets the UIView which will be used inside the minimum thumb.
 */
@property (retain)UIView* maximumThumbView;

/** An object that defines a set of brushes and fonts that will be used to style the range selector.
 */
@property (nonatomic, retain) id<IGRangeSelectorThemeDefinition> theme;

@end
