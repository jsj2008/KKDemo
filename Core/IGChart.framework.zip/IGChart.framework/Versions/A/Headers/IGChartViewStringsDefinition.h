//
//  VisualChartData.h
//
//  Copyright (c) 2013 Infragistcs. All rights reserved.
//

#import <Foundation/Foundation.h>

/*!
 The IGSeriesStringsDefinition protocol is adopted by an object that replaces default strings off various objects in the IGChartView object.
 
 All methods and properties in this protocol are optional.
 
 */
@protocol IGSeriesStringsDefinition <NSObject>

@optional

/** The string used for the Item labels when using the IGSeriesDataSourceHelper.
 
 If you provide a labelPath this property will simply be ignored. 
 */
@property(nonatomic, readonly)NSString* defaultItemText;

@end

/*!
 An English Translation of all strings in the IGChartView.
 */
@interface IGSeriesEnglishStrings : NSObject<IGSeriesStringsDefinition>
@end

/*!
 A Japanese Translation of all strings in the IGChartView.
 */
@interface IGSeriesJapaneseStrings : NSObject<IGSeriesStringsDefinition>
@end
