//
//  VisualChartData.h
//
//  Copyright (c) 2012 Infragistcs. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreGraphics/CoreGraphics.h>
#import <UIKit/UIKit.h>

@class VisualDataPrimitive;
@class AppearanceDataPrimitive;
@class AppearanceDataLabel;
@class VisualPieSliceData;

/*!
    This class provides information related to objects that were rendered and is not for public usage.
 */
@interface VisualChartData : NSObject 
{
    @public
    NSMutableArray* axes;
    NSMutableArray* series;
    NSString* name;
    BOOL isViewportScaled;
}

- (id)initWithGeneratedObject:(id)obj;

- (void)scaleByViewport;

@end

/*!
 This class provides information related to objects that were rendered and is not for public usage.
 */
@interface VisualPieChartData : NSObject
{
    @public
    NSMutableArray *slices;
    VisualPieSliceData *othersSlice;
    NSString *name;
    NSMutableArray *others;
}
-(id)initWithGeneratedObject:(id)obj;
@end

/*!
 This class provides information related to objects that were rendered and is not for public usage.
 */
@interface VisualFunnelChartData : NSObject
{
    @public
    NSMutableArray *slices;
    NSString *name;
}
-(id)initWithGeneratedObject:(id)obj;
@end

/*!
 This class provides information related to objects that were rendered and is not for public usage.
 */
@interface VisualDataAxis : NSObject
{
@public
    NSString* name;
    NSString* type;
    CGRect viewport;
    NSMutableArray* labels; // VisualDataAxisLabel
    VisualDataPrimitive* axisLine;
    VisualDataPrimitive* majorLines;
    VisualDataPrimitive* minorLines;
}

- (id)initWithGeneratedObject:(id)obj;

@end

/*!
 This class provides information related to objects that were rendered and is not for public usage.
 */
@interface VisualDataPrimitive : NSObject
{
@public
    AppearanceDataPrimitive* appearance;
    NSMutableArray* tags; // Strings
    NSString* name;
    NSString* type;
    double radiusX, radiusY; // rounded corner radius
}

- (id)initWithGeneratedObject:(id)obj;
- (NSArray*)getPoints;

@end

/*!
 This class provides information related to objects that were rendered and is not for public usage.
 */
@interface AppearanceDataPrimitive : NSObject
{
@public
    UIColor* stroke;
    UIColor* fill;
    double strokeThickness;
    NSInteger visibility;
    double opacity;
    double canvasLeft;
    double canvasTop;
    NSInteger canvaZIndex;
    NSMutableArray *dashArray;
    NSInteger dashCap;
}

- (id)initWithGeneratedObject:(id)obj;

@end

/*!
 This class provides information related to objects that were rendered and is not for public usage.
 */
@interface VisualDataAxisLabel : NSObject
{
@public
    NSObject* labelValue;
    double labelPosition;
    AppearanceDataLabel* appearance;
}

- (id)initWithGeneratedObject:(id)obj;

@end

/*!
 This class provides information related to objects that were rendered and is not for public usage.
 */
@interface AppearanceDataLabel : NSObject
{
@public
    NSString* text;
    UIColor *labelColor;
    BOOL visible;
    double angle;
}

- (id)initWithGeneratedObject:(id)obj;

@end

/*!
 This class provides information related to objects that were rendered and is not for public usage.
 */
@interface VisualDataSeries : NSObject
{
@public
    NSString* name;
    NSString* type;
    CGRect viewport;
    NSMutableArray* shapes;
    NSMutableArray* markerShapes;
}

- (id)initWithGeneratedObject:(id)obj;

@end

/*!
 This class provides information related to objects that were rendered and is not for public usage.
 */
@interface VisualDataStackedSeries : VisualDataSeries
{
@public
    NSMutableArray *_fragmentSeries;
}
@end

/*!
 This class provides information related to objects that were rendered and is not for public usage.
 */
@interface VisualDataMarker : NSObject
{
@public
    double x;
    double y;
    NSInteger index;
    NSInteger visibility;
    AppearanceDataPrimitive* appearance;
    NSString* markerType;
    UIView *customMarkerView;
}

- (id)initWithGeneratedObject:(id)obj;

@end

/*!
 This class provides information related to objects that were rendered and is not for public usage.
 */
@interface VisualPieSliceData : NSObject
{
    @public
    CGFloat startAngle, endAngle, radius, explodedRadius, innerExtentStart, innerExtentEnd;
    CGPoint origin, explodedOrigin;
    BOOL isSelected, isExploded, isOthersSlice;
    NSInteger index;
    NSString *label;
    CGRect labelBounds;
    AppearanceDataPrimitive *appearance;
    AppearanceDataLabel *labelAppearance;
    AppearanceDataPrimitive *leaderLineAppearance;
    VisualDataPrimitive *slicePath;
}
-(id)initWithGeneratedObject:(id)obj;
@end

/*!
 This class provides information related to objects that were rendered and is not for public usage.
 */
@interface VisualFunnelSliceData : NSObject
{
    @public
    BOOL isSelected;
    NSInteger index;
    NSString *innerLabel, *outerLabel;
    CGRect innerLabelBounds, outerLabelBounds;
    AppearanceDataPrimitive *appearance;
    AppearanceDataLabel *innerLabelAppearance;
    AppearanceDataLabel *outerLabelAppearance;
    NSArray *slicePoints;
    NSArray *slicePointsUsingCGPoints;
    UIFont *font;
}
-(id)initWithGeneratedObject:(id)obj;
@end

/*!
 This class provides information related to objects that were rendered and is not for public usage.
 */
@interface VisualGaugeData : NSObject
{
    @public
    VisualDataPrimitive *_scalePath;
    VisualDataPrimitive *_needlePath;
    VisualDataPrimitive *_backingPath;
    VisualDataPrimitive *_underlayPath;
    VisualDataPrimitive *_overlayPath;
    
    NSMutableArray *_scaleLabels;
    NSMutableArray *_scaleTickmarks;
    NSMutableArray *_ranges;
    
    UIFont *_font;
}
-(id)initWithGeneratedObject:(id)obj;
@end

/*!
 This class provides information related to objects that were rendered and is not for public usage.
 */
@interface VisualGaugeScaleLabelData : NSObject
{
    @public
    NSObject* labelValue;
    CGPoint labelPosition;
    AppearanceDataLabel* appearance;
}
-(id)initWithGeneratedObject:(id)obj;
@end

/*!
 This class provides information related to objects that were rendered and is not for public usage.
 */
@interface VisualGaugeScaleTickmarkData : NSObject
{
    @public
    VisualDataPrimitive *_tickPath;
}
-(id)initWithGeneratedObject:(id)obj;
@end

/*!
 This class provides information related to objects that were rendered and is not for public usage.
 */
@interface VisualGaugeRangeData : NSObject
{
@public
    VisualDataPrimitive *_rangePath;
}
-(id)initWithGeneratedObject:(id)obj;
@end

/*!
 This class provides information related to objects that were rendered and is not for public usage.
 */
@interface VisualSparklineVisualData : NSObject
{
    @public
    VisualDataPrimitive *_sparkPath;
    VisualDataPrimitive *_negativeSparkPath;
    VisualDataPrimitive *_trendLinePath;
    VisualDataPrimitive *_rangePath;
    VisualDataPrimitive *_markersPath;
    VisualDataPrimitive *_negativeMarkersPath;
    VisualDataPrimitive *_lowMarkersPath;
    VisualDataPrimitive *_highMarkersPath;
    VisualDataPrimitive *_firstMarkerPath;
    VisualDataPrimitive *_lastMarkerPath;
    
    VisualDataPrimitive* _xAxisLine;
    VisualDataPrimitive* _yAxisLine;
}
-(id)initWithGeneratedObject:(id)obj;
@end

@interface IGBulletGraphTargetValueVisualData : NSObject {
@public
    double value;
}
-(id)initWithGeneratedObject:(id)obj;
@end

@interface IGLinearGraphRangeVisualData : NSObject
{
    @public
    VisualDataPrimitive* rangePath;
}
-(id)initWithGeneratedObject:(id)obj;
@end

@interface IGLinearGraphScaleTickmarkVisualData : NSObject
{
    @public
    VisualDataPrimitive* tickMarkPath;
}
-(id)initWithGeneratedObject:(id)obj;
@end

@interface IGLinearGraphScaleLabelVisualData : NSObject
{
    @public
        NSObject* labelValue;
        CGSize labelSize;
        CGPoint labelPosition;
        AppearanceDataLabel* appearance;

}
-(id)initWithGeneratedObject:(id)obj;
@end

@interface VisualBulletChartData : NSObject
{
    @public
    VisualDataPrimitive* targetValuePath;
    IGBulletGraphTargetValueVisualData* targetValue;
    UIFont* font;
    
    VisualDataPrimitive* scalePath;
    VisualDataPrimitive* backingPath;
    VisualDataPrimitive* underlayPath;
    VisualDataPrimitive* overlayPath;
    VisualDataPrimitive* valuePath;

    NSArray* scaleLabels;
    NSArray* scaleTickmarks;
    NSArray* ranges;
}
-(id)initWithGeneratedObject:(id)obj;
@end

@interface VisualLinearGaugeData : NSObject
{
@public
    UIFont *font;

    VisualDataPrimitive *scalePath;
    VisualDataPrimitive *backingPath;
    VisualDataPrimitive *needlePath;

    NSArray *scaleLabels;
    NSArray *scaleTickmarks;
    NSArray *ranges;
}
-(id)initWithGeneratedObject:(id)obj;
@end
