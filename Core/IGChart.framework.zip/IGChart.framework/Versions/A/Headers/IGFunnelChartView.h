#import <Foundation/Foundation.h>
#import <CoreGraphics/CoreGraphics.h>
#import <UIKit/UIKit.h>
#import "Enums.h"
#import "Core.h"
#import "IGLegend.h"
#import "VisualChartData.h"
#import "Themes.h"
#import "Series.h"
#import "IGSeriesDataSourceHelper.h"

@class DataChartContainer;
@class LegendContainer;
@class IGFunnelChartView;
@class IGFunnelSliceInfo;

/*! This protocol has methods that provide the ability to interact with the funnel chart.
 */
@protocol IGFunnelChartViewDelegate <NSObject>
@optional
/** This method allows the user to supply a UIView that will be used as a tooltip for a funnel slice.
 @param funnelChartView Reference to the funnel chart.
 @param item Information about the current funnel slice.
 @return Returns the view that will be the slice's tooltip.
 */
-(UIView*)funnelChartView:(IGFunnelChartView*)funnelChartView viewForTooltipWithItem:(IGFunnelSliceInfo*)info;

/** This method provides the handling of the tap gesture.
 @param funneleChartView Reference to the funnel chart.
 @param item Information about the current funnel slice.
 @param point The touch location.
 */
-(void)funnelChartView:(IGFunnelChartView*)funnelChartView tapWithItem:(IGFunnelSliceInfo*)item atPoint:(CGPoint)point;

/** This methods allows the user to change funnel slice's inner label that is about to be displayed.
 @param funnelChartView Reference to the funnel chart.
 @param oldLabel Previous inner label of the slice.
 @param index Index of the current slice.
 @return Returns a string that will be used as the slice's inner label.
 */
-(NSString*)funnelChartView:(IGFunnelChartView*)funnelChartView innerLabelWithOldLabel:(NSString*)oldLabel index:(NSInteger)index;

/** This methods allows the user to change funnel slice's outer label that is about to be displayed.
 @param funnelChartView Reference to the funnel chart.
 @param oldLabel Previous inner label of the slice.
 @param index Index of the current slice.
 @return Returns a string that will be used as the slice's outer label.
 */
-(NSString*)funnelChartView:(IGFunnelChartView*)funnelChartView outerLabelWithOldLabel:(NSString*)oldLabel index:(NSInteger)index;
@end


/*! This class contains properties that present valuable information about a funnel chart slice.
 
 This class is typically used when handling interactions, such as tap and long press gestures. It provides information, such as whether the slice is selected. It also provides the underlying data point.
 */
@interface IGFunnelSliceInfo : NSObject
{
    NSObject *_item;
}
/** Determines whether the slice is selected.
 Selected slices have a distinct style and multiple slices can be selected at the same time.
 */
@property (nonatomic) BOOL isSelected;

/** The underlying data object of the current slice. (read-only)
 */
@property (nonatomic, readonly) NSObject* item;
@end


/*! IGFunnelChartViewDataSource protocol represents the data model object used by the funnel chart. It provides the means to supply the funnel chart with data.
 This protocol can be implemented by the user to provide full control over the data that goes into the funnel chart. Alternatively, IGFunnelChartViewDataSourceHelper can be used to simply that process.
 */
@protocol IGFunnelChartViewDataSource <NSObject>
@required
/** This method specifies the number of data items in the funnel chart.
 @param funnelChartView Reference to the funnel chart.
 @return Returns the number of data items in the funnel chart.
 */
-(NSInteger)numberOfPointsInFunnelChartView:(IGFunnelChartView*)funnelChartView;

/** This method supplies an IGDataPoint reference to the funnel chart at a given index.
 @param funnelChartView Reference to the funnel chart.
 @param index The current index.
 @return Returns an initialized IGDataPoint to be used by the funnel chart.
 */
-(IGDataPoint*)funnelChartView:(IGFunnelChartView*)funnelChartView pointAtIndex:(NSInteger)index;
@optional
/** This method can be used to supply the funnel chart with a range of data points. If this method is implemented the datasource will not respond to numberOfPointsInFunnelChartView or pointAtIndex.
 @param funnelChartView Reference to the funnel chart.
 @return Returns a range of initialized points.
 */
-(NSArray*)allPointsForSeries:(IGFunnelChartView*)funnelChartView;

/** Returns the original data object at a specified index.
 @param index Index of the data object to be returned.
 @return Returns the data object at a specified index.
 */
-(NSObject*)objectAtIndex:(NSInteger)index;

/** Returns the original data object based on its corresponding data point.
 @param point IGDataPoint that represents the original object.
 @param funnelChartView Reference to the funnel chart.
 @return Returns the data object that corresponds to the given data point.
 */
-(NSObject*)objectForDataPoint:(IGDataPoint*)point inFunnelChartView:(IGFunnelChartView*)funnelChartView;
@end



/*! This data source helper is used to create a data source for the funnel chart.
 The data source helper provides a simplified way of supplying data for the funnel chart. The resulting data structure contains multiple IGCategoryPoint instances.
 */
@interface IGFunnelChartViewDataSourceHelper : NSObject<IGFunnelChartViewDataSource>

/** An array of custom data objects. The fields in the data object are accessed via memberPath properties.
 */
@property (nonatomic, retain) NSArray* data;

/** An array of string labels used to create inner labels for data points.
 */
@property (nonatomic, retain) NSArray* innerLabels;

/** Name of the property containing inner abels.
 */
@property (nonatomic, retain) NSString* innerLabelPath;

/** An array of string labels used to create outer labels for data points.
 */
@property (nonatomic, retain) NSArray* outerLabels;

/** Name of the property containing outer labels.
 */
@property (nonatomic, retain) NSString* outerLabelPath;

/** A numeric array of values used to create data points.
 */
@property (nonatomic, retain) NSArray* values;

/** A string value path that specifies the property in the data source used for values.
 */
@property (nonatomic, retain) NSString *valuePath;

///--------------------
///@name Initializing DataSource Helper
///--------------------

/** Initializes the data source with an array of numeric values.
 @param values Array of numeric values.
 @return Returns an initialized data source.
 */
-(id)initWithValues:(NSArray*)values;

/** Initializes the data source with an array of numeric values and string labels.
 @param values Array of numeric values.
 @param innerLabels Array of inner string labels.
 @param outerLabels Array of outer string labels.
 @return Returns an initialized data source.
 */
-(id)initWithValues:(NSArray*)values innerLabels:(NSArray*)innerLabels outerLabels:(NSArray*)outerLabels;

/** Initializes the data source with an array of custom data objects.
 @param data Array of custom objects.
 @param valuePath The name of the property containing values.
 @return Returns an initialized data source.
 */
-(id)initWithData:(NSArray*)data valuePath:(NSString*)valuePath;

/** Initializes the data source with an array of custom data objects.
 @param data Array of custom objects.
 @param valuePath The name of the property containing values.
 @param innerLabelPath The name of the property containing inner labels.
 @param outerLabelPath The name of the property containing outer labels.
 @return Returns an initialized data source.
 */
-(id)initWithData:(NSArray*)data valuePath:(NSString*)valuePath innerLabelPath:(NSString*)innerLabelPath outerLabelPath:(NSString*)outerLabelPath;
@end


/*! This class represents the funnel chart view.
 
 The funnel chart view is a data visualization tool that displays funnel slices with progressively increasing or decreasing values. The shape of the funnel chart most often resembles an upside-down trapezoid. Funnel chart data is a collection of numeric values, and each slice represents one value. 
 
 The funnel chart view supports multiple slice selection, tooltips, tap and long press gestures.
 */
@interface IGFunnelChartView : UIView
{
    DataChartContainer *_chartContainer;
    NSMutableArray *_brushes, *_outlines;
    id<IGFunnelChartThemeDefinition> _theme;
    NSMutableArray *_dataPoints;
    NSInteger _numberOfPoints;
    IGBrush *_selectedBrush, *_selectedOutline;
    CGFloat _selectedOutlineThickness;
    
    IGBrush *_resolvedSelectedBrush, *_resolvedSelectedOutline;
    CGFloat _resolvedSelectedOutlineThickness;
}

/** Sets the interaction delegate for the funnel chart.
 */
@property (nonatomic, assign) id<IGFunnelChartViewDelegate> delegate;

/** Sets the data source for the funnel chart view. This can be an interface that conforms to IGFunnelChartViewDataSource protocol or an instance of IGFunnelChartViewDataSourceHelper.
 */
@property (nonatomic, assign) id<IGFunnelChartViewDataSource> dataSource;

/** Returns an array of IGCategoryPoint objects. (read-only)
 */
@property (nonatomic, readonly) NSMutableArray *dataPoints;

/** Determines whether selected slices appear as selected or not.
 When set to false, this property disables all visual cues that indicate that a slice is selected. All selected slices will appear as not selected. Once this property is set to true, any slices that are marked as selected will visually appear as selected. Changing the value of this property has no effect on the selectedSlices property.
 */
@property (nonatomic) BOOL allowSliceSelection;

/** An array of IGBrush objects that are used to color the funnel slices. This array takes precedence over themes.
 */
@property (nonatomic, retain) NSArray* brushes;

/** An array of IGBrush objects that are used to color the slice outlines. This array takes precedence over themes.
 */
@property (nonatomic, retain) NSArray* outlines;

/** Determines the thickness of the outline around the slices.
 */
@property (nonatomic) CGFloat outlineThickness;

/** Determines the brush of selected slices.
 */
@property (nonatomic, retain) IGBrush *selectedBrush;

/** Determines the outline color around selected slices.
 */
@property (nonatomic, retain) IGBrush *selectedOutline;

/** Determines the thickness of the outline around selected slices.
 */
@property (nonatomic) CGFloat selectedOutlineThickness;

/** Determines the brush of selected slices.
 */
@property (nonatomic, readonly) IGBrush *resolvedSelectedBrush;

/** Determines the outline color around selected slices.
 */
@property (nonatomic, readonly) IGBrush *resolvedSelectedOutline;

/** Determines the thickness of the outline around selected slices.
 */
@property (nonatomic, readonly) CGFloat resolvedSelectedOutlineThickness;

/** Determines the font used by the funnel chart labels.
 This is the default font for the labels of the slices that are not selected. Selected labels and the others label have their own font properties.
 */
@property (nonatomic, retain) UIFont *font;

/** Determines the font brush used by the funnel char labels.
 This is the default font brush for the labels of the slices that are not selected. Selected labels and the others label have their own font brush properties.
 */
@property (nonatomic, retain) IGBrush *fontBrush;

/** Associates an item legend with the funnel chart.
 */
@property (nonatomic, assign) IGLegend *legend;

/** Determines the width of the bottom of the funnel. This value should be between 0 and 1 and is expressed as percentage of the total width of the control.
 For example, setting this property to 0 will create a pointy bottom, while setting it to 1 will make the bottom take up the entire width of the control.
 */
@property (nonatomic) CGFloat bottomEdgeWidth;

/** Determines the display style of the funnel.
 This property can be set to Weighted or Uniform. When using Weighted style, the height of each slice is based on the underlying value. In Uniform style the height of all slices is constant and depends on the size of the control.
 */
@property (nonatomic) IGFunnelSliceDisplay funnelSliceDisplay;

/** Determines whether the inner labels should be visible.
 */
@property (nonatomic) BOOL innerLabelsVisible;

/** Determines whether the outer labels should be visible.
 */
@property (nonatomic) BOOL outerLabelsVisible;

/** Determines if the slices should be displayed in reverse order.
 */
@property (nonatomic) BOOL isInverted;

/** Specifies the lower control point if a bezier curve is used to define the funnel.
 */
@property (nonatomic) CGPoint lowerBezierControlPoint;

/** Determines whether the outer labels should be on the left or the right side of the funnel.
 */
@property (nonatomic) IGFunnelOuterLabelAlignment outerLabelAlignment;

/** An index collection of selected sliced.
 
 This property contains a set of indices that represent the selected slices. For example, a set of {0,1,3} means that the first, second and fourth slices are selected.
 */
@property (nonatomic, retain) NSIndexSet *selectedSlices;

/** Returns an array of selected items from the datasource.
 
 This property returns instances of IGFunnelPoint that are selected.
 */
@property (nonatomic, readonly) NSArray *selectedItems;

/** Determines the length (in seconds) of the animation.
 */
//@property (nonatomic) CGFloat transitionDuration;

/** Specifies the tooltip location.
 
 This property determines where the tooltip will be positioned. The default setting uses a floating tooltip, which follows the location of the long press. Tooltip can also be pinned to top, bottom, left, or right.
 */
@property (nonatomic) IGTooltipPinLocation tooltipPinLocation;

/** Specifies the upper control point if a bezier curve is used to define the funnel.
 */
@property (nonatomic) CGPoint upperBezierControlPoint;

/** Determines whether a bezier curve should be used to define the funnel.
 */
@property (nonatomic) BOOL useBezierCurve;

/** Specifies whether outer labels should be displayed in the legend items, when a legend is associated with the funnel.
 By default inner labels are used.
 */
@property (nonatomic) BOOL useOuterLabelsForLegend;

/** This property can be used to apply a theme to a funnel chart.
 
 This can be a pre-defined or a custom theme.
 Pre-defined themes can be used by setting this property to one of the themes in IGFunnelChartDefaultThemes interface.
 */
@property (nonatomic, assign) id<IGFunnelChartThemeDefinition> theme;

/** Determines the rendering quality of the chart.
 This property only affects retina displays. By default, the chart will render with high quality. If the chart contains too many data points and its performance begins to degrade due to a high number of shapes, setting a lower rendering quality will increase the performance.
 */
@property (nonatomic) IGRenderingQuality renderingQuality;

///----------------------
///@name Configuring the funnel chart view
///----------------------

/** Returns a data representation of the visuals of the funnel chart.
 
 This method is available to provide a way to do validation for testing of the visuals of the funnel chart.
 */
- (VisualFunnelChartData*)exportVisualData;

///-------------------------
///@name Notifying the funnel chart view of data source changes
///-------------------------

/** Notifies the chart view that all items in the data source were cleared.
 
 This method is used to tell the chart view that all of the items in a given data source have been removed.
 @param source Data source that had its items removed.
 */
-(void) clearItemsForDataSource:(id<IGFunnelChartViewDataSource>)source;

/** Notifies the chart view that an item has been inserted in the data source.
 
 This method is used to tell the chart view that an item has been inserted into a given data source at a given index.
 @param index Index of an item that has been inserted.
 @param source Data source that had an item inserted.
 */
-(void) insertItemAtIndex:(NSInteger)index withSource:(id<IGFunnelChartViewDataSource>)source;

/** Notifies the chart view that an item has been removed from the data source.
 
 This method is used to tell the chart view that an item has been removed from a given data source at a given index.
 @param index Index of an item that has been removed.
 @param source Data source that had an item removed.
 */
-(void) removeItemAtIndex:(NSInteger)index withSource:(id<IGFunnelChartViewDataSource>)source;

/** Notifies the chart view that an item has been replaced in the data source.
 
 This method is used to tell the chart view that an item has been replaced in a given data source at a given index.
 @param index Index of an item that has been replaced.
 @param source Data source that had an item replaced.
 */
-(void) replaceItemAtIndex:(NSInteger)index withSource:(id<IGFunnelChartViewDataSource>)source;

/** Notifies the chart view that an item has been updated in the data source.
 
 This method is used to tell the chart view that an item has been updated in a given data source at a given index.
 @param index Index of an item that has been replaced.
 @param source Data source that had an item replaced.
 */
-(void)updateItemAtIndex:(NSInteger)index withSource:(id<IGFunnelChartViewDataSource>)source;
@end
