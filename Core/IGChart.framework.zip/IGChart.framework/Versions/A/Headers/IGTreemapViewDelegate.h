#import <Foundation/Foundation.h>

@class IGTreemapView;
@class IGTreemapNode;

@protocol IGTreemapViewDelegate <NSObject>
@optional
/** This method allows the user to supply a UIView that will be used as a tooltip for a treemap node.
 @param treemapView Reference to the treemap.
 @param node Current treemap node.
 @return Returns the view that will be the treemap node's tooltip.
 */
-(UIView*)treemapView:(IGTreemapView*)treemapView viewForTooltipWithNode:(IGTreemapNode*)node;

/** This method provides the handling of the tap gesture.
 @param treemapView Reference to the treemap.
 @param node Current treemap node.
 @param point The touch location.
 */
-(void)treemapView:(IGTreemapView*)treemapView tapWithNode:(IGTreemapNode*)node atPoint:(CGPoint)point;

/** Handles the pinch gesture. The treemap will drill back to the parent node on pinch in, when this delegate method isn't handled.
 @param treemapView Reference to the treemap. 
 @param node current root node of the treemap.
 */
-(void)treemapView:(IGTreemapView*)treemapView handlePinchGestureWithNode:(IGTreemapNode*)node;

/** Provides a custom view to be used for any leaf node.
 Use this method to place a custom view in a leaf node. This can be useful during drill down: as leaf nodes become larger, they can display additional content.
 @param treemapView Reference to the treemap.
 @param node Current treemap node.
 @return Returns the view that will be placed in the lead node.
 */
-(UIView*)treemapView:(IGTreemapView*)treemapView viewForLeafWithNode:(IGTreemapNode*)node;
@end
