#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import <Foundation/Foundation.h>
#import "IGTreemapNode.h"
#import "IGTreemapViewDataSourceHelper.h"
#import "IGTreemapViewDataSource.h"
#import "IGTreemapThemeDefinition.h"
#import "IGTreemapViewDelegate.h"
#import "IGTreemapThemes.h"
#import "IGTreemapNodeColorMapper.h"
#import "Enums.h" 
#import "Core.h"

@class IGTreemapNodeColorMapper;

/*!
 IGTreemapView is designed to display a hierarchical data structure of treemap nodes, where each node is represented by a rectangle. Each treemap node can have any number of child nodes and the children are sorted by size, from largest to smallest. 
 
 A typical data source for the treemap is an array of custom objects, each of which can potentially hold an array of custom objects. A treemap datasource must conform to IGTreemapViewDataSource protocol. IGTreemapViewDataSourceHelper provides a way to easily create a valid datasource by supplying the property paths for the nodes to bind to at each level of the treemap.
 
 There are several layout algorithms that define the layout of the treemap nodes. Those are controlled by layoutOrientation and layoutType properties. 
 
 The treemap supports themes. There are predefined themes available in IGTreemapThemes.h. Custom themes can be created by implementing IGTreemapThemeDefinition protocol. Theme colors are applied per level in the treemap. The same effect can be achieved by assigning an array of brushes and outlines via brushes and outlines properties. Treemap nodes can also get their brushes from a color mapper. IGTreemapNodeColorMapper can be used to conditionally set node brushes based on the node's size or based on any other property value in the data source.
 
 The treemap supports transitional animations via transitionDuration property. Nodes will animate their frame changes when layout changes or during drill-down and drill-back operations. Drill-down and drill-back are built into the treemap and will be triggered by tapping on a node and pinching in respectively. These triggers can be overridden by implementing the treemap delegate.
 
 The tremap has two rendering modes: UIView (default) and immediate mode. By default each node will be treated as a child UIView or its parent node. This makes the node support any operations available in a UIView, such as custom content. During immediate mode rendering, all nodes are drawn using core graphics, which makes the treemap perform faster at the cost of flexibility of using views.
 */
@interface IGTreemapView : UIView

/** Determines the orientation of the treemap. 
 SliceAndDice and Strip layouts support orientation, while Squarified layout does not.
 */
@property (nonatomic) IGTreemapLayoutOrientation layoutOrientation;

/** Determines the layout of the nodes in the treemap. Available options are Squarified (default), SliceAndDice and Strip. SliceAndSice has the highest aspect ratio and preserves the order of the nodes. Squarified and Strip have lower aspect ratio and create a more visually appealing treemap. Additionally, SliceAndDice and Strip layouts support horizontal and vertical orientation.
 */
@property (nonatomic) IGTreemapLayoutType layoutType;

/** Determines the current root node of the treemap.
 The root node is the top level node currently in view. During the drill-down and drill-back the root node will change to reflect the current top level node.
 */
@property (nonatomic, retain) IGTreemapNode *rootNode;

/** Specifies the treemap datasource.
 The datasource must conform to the IGTrteemapViewDataSource protocol. This property can be set to a custom implementation of the protocol or a predefined datasource helper.
 */
@property (nonatomic, assign) id<IGTreemapViewDataSource> dataSource;

/** Specifies the theme for the treemap.
 This can be one of the predefined themes or a custom theme that implements IGTreemapThemeDefinition protocol. Setting properties on the treemap, such as brushes, outlines, font, etc. will take precedence over the theme settings. Also using a color mapper will take precedence over the theme.
 */
@property (nonatomic, assign) id<IGTreemapThemeDefinition> theme;

/** Provides a way to handle user interactions with the treemap.
 The protocol contains methods that allow custom handling of various aspects of the treemap, such as tooltips, custom node content and gestures.
 */
@property (nonatomic, assign) id<IGTreemapViewDelegate> delegate;

/** Determines how the nodes are rendered.
 The treemap supports two rendering modes: UIView and Immediate. UIView mode is the default and is more flexible. It treats all nodes as views and allows custom content to be placed in the nodes. The treemap will take a performance hit when there are too many nodes. Immediate mode will draw all nodes using core graphics. It is much faster but doesn't allow custom content in nodes.
 */
@property (nonatomic) IGTreemapRenderingMode renderingMode;

/** Specifies the tooltip location.
 
 This property determines where the tooltip will be positioned. The default setting uses a floating tooltip, which follows the location of the long press. Tooltip can also be pinned to top, bottom, left, or right. The tooltip view must be supplied to the treemap via the IGTreemapViewDelegate method -treemap:viewForTooltipWithNode:
 */
@property (nonatomic) IGTooltipPinLocation tooltipPinLocation;

/** Specifies the amount of space around the tree node.
 The default padding is (10,10,10,10) 10 pixels around the node.
 */
@property (nonatomic) CGRect nodePadding;

/** Determines the amount of space between the label and the edge of the node.
 */
@property (nonatomic) CGFloat nodeLabelPadding;

/** Determines the duration (in seconds) of the animation.
 */
@property (nonatomic) CGFloat transitionDuration;

/** Determines the smallest allowable size of a treemap node that gets rendered.
 The value of this property is the minimum pixel width or height of the node, which ever one is the smallest. The default value is 3, so nodes with width or height less than 3 will not be displayed.
 */
@property (nonatomic) CGFloat minimumVisibleNodeSize;

/** Determines the maximum depth of the treemap.
 This property sets the number of levels a treemap can have.
 */
@property (nonatomic) NSInteger maximumDepth;

/** An array of IGBrush objects used to color the treemap nodes. 
 Each brush in the array is applied to the entire level in order. These brushes take precedence over themes, but not the color mapper.
 */
@property (nonatomic, retain) NSArray *brushes;

/** An array of IGBrush objects used to color the borders of the treemap nodes.
 Each brush in the array is applied to the entire level in order. These brushes take precedence over themes.
 */
@property (nonatomic, retain) NSArray *outlines;

/** Determines if the treemap should be updated.
 When set to NO, the treemap will not be updated when other properties change. Setting this property to YES will update the treemap.
 */
@property (nonatomic) BOOL suspendUpdates;

/** Determines the font brush for the labels in the treemap. Setting this property will take precedence over the themes.
 */
@property (nonatomic, retain) IGBrush *fontBrush;

/** Determines the font used by the treemap labels.
 This is the default font for the labels in the treemap. Setting this property will take precedence over the themes.
 */
@property (nonatomic, retain) UIFont *font;

/** Returns the height of the treemap's font. (read-only)
 */
@property (nonatomic, readonly) CGFloat fontHeight;

/** Determines the vertical space reserved for the node header.
 */
@property (nonatomic) CGFloat nodeHeaderHeight;

/** Determines the border thickness of the treemap nodes.
 */
@property (nonatomic) CGFloat borderThickness;

/** Returns the resolved font brush that will be used for the treemap labels. (read-only)
 This property is the font brush that's set via the theme or directly on the treemap.
 */
@property (nonatomic, readonly) IGBrush *resolvedFontBrush;

/** Returns the resolved font that will be used for the treemap labels. (read-only)
 This property is the font that's set via the theme or directly on the treemap.
 */
@property (nonatomic, readonly) UIFont *resolvedFont;

/** Returns the resolved brushes used by the treemap. (read-only)
 This property returns a set of brushes that will be used to color the nodes. These brushes could come from the theme or brushes property.
 */
@property (nonatomic, readonly) NSArray *resolvedBrushes;

/** Returns the resolved outlines used by the treemap. (read-only)
 This property returns a set of brushes that will be used to color the node outlines. These brushes could come from the theme or outlines property.
 */
@property (nonatomic, readonly) NSArray *resolvedOutlines;

/** Specifies the color mapper to color the treemap nodes.
 The color mapper is a color range set by start and end colors. It will map the colors of all applicable nodes based on the color mapper's properties.
 */
@property (nonatomic, retain) IGTreemapNodeColorMapper *colorMapper;

/** Determines the treemap resoluion during animation.
 This property can be used to reduce the resolution of the treemap during the animation cycle. The value of this property should be greater than zero and is typically less than or equal to one. This only affects the treemap when renderingMode is set to Immediate. The values closer to one will maintain a higher resolution, while values closer to 0 will use lower resolution and make the tree look more distorted. When the treemap has too many nodes to animate smoothly, reducing the value of this property will provide a performance boost.
 */
@property (nonatomic) CGFloat animationAliasingFactor;

/** Determines the rendering quality of the treemap.
 This property only affects retina displays and the treemap has to use Immediate mode rendering. By default, the treemap will render with high quality. If the treemap contains too many nodes and its performance begins to degrade due to a high number of shapes, setting a lower rendering quality will increase the performance.
 */
@property (nonatomic) IGRenderingQuality renderingQuality;

/** Returns internal frame structure of the treemap. (read-only)
 */
@property (nonatomic, readonly) NSObject *treemapInternalFrames;

///----------------------
///@name Configuring the treemap view
///----------------------

/** Calling this method will force the treemap to update itself.
 */
-(void)refresh;

/** Returns whether or not the treemap is currently in an animation cycle.
 @return Returns YES if currently running an animation, otherwise NO.
 */
-(BOOL)isAnimating;

/** Returns a treemap node that was created based on the given source object.
 @param source Data model object used to create the node.
 @return Returns a treemap node that was created based on the source object.
 */
-(IGTreemapNode*)nodeWithSourceObject:(NSObject*)source;
@end
