#import <Foundation/Foundation.h>
#import <CoreGraphics/CoreGraphics.h>
#import <UIKit/UIKit.h>
#import "Enums.h"
#import "Core.h"
#import "IGLegend.h"
#import "VisualChartData.h"
#import "Themes.h"
#import "Series.h"
#import "IGSeriesDataSourceHelper.h"

@class DataChartContainer;
@class LegendContainer;
@class IGPieChartView;
@class IGPieSliceInfo;

/*! This protocol has methods that provide the ability to interact with the pie chart.
 */
@protocol IGPieChartViewDelegate <NSObject>
@optional
/** This method allows the user to supply a UIView that will be used as a tooltip for a pie slice.
 @param pieChartView Reference to the pie chart.
 @param item Information about the current pie slice.
 @return Returns the view that will be the slice's tooltip.
 */
-(UIView*)pieChartView:(IGPieChartView*)pieChartView viewForTooltipWithItem:(IGPieSliceInfo*)item;

/** This method provides the handling of the tap gesture.
 @param pieChartView Reference to the pie chart.
 @param item Information about the current pie slice.
 @param point The touch location.
 */
-(void)pieChartView:(IGPieChartView*)pieChartView tapWithItem:(IGPieSliceInfo*)item atPoint:(CGPoint)point;

/** This methods allows the user to change pie chart label that is about to be displayed.
 @param pieChartView Reference to the pie chart.
 @param label The pie label that's about to be displayed.
 @param item Information about the current pie slice.
 @return Returns a string that will be used as the slice's label.
 */
-(NSString*)pieChartView:(IGPieChartView*)pieChartView label:(NSString*)label item:(IGPieSliceInfo*)item;
@end


/*! IGPieChartViewDataSource protocol represents the data model object used by the pie chart. It provides the means to supply the pie chart with data.
 This protocol can be implemented by the user to provide full control over the data that goes into the pie chart. Alternatively, IGPieChartViewDataSourceHelper can be used to simply that process.
 */
@protocol IGPieChartViewDataSource <NSObject>
@required
/** This method specifies the number of data items in the pie chart.
 @param pieChartView Reference to the pie chart.
 @return Returns the number of data items in the pie chart.
 */
-(NSInteger)numberOfPointsInPieChartView:(IGPieChartView*)pieChartView;

/** This method supplies an IGDataPoint reference to the pie chart at a given index.
 @param pieChartView Reference to the pie chart.
 @param index The current index.
 @return Returns an initialized IGDataPoint to be used by the pie chart.
 */
-(IGDataPoint*)pieChartView:(IGPieChartView*)pieChartView pointAtIndex:(NSInteger)index;
@optional
/** This method can be used to supply the pie chart with a range of data points. If this method is implemented the datasource will not respond to numberOfPointsInPieChartView or pointAtIndex.
 @param pieChartView Reference to the pie chart.
 @return Returns a range of initialized points.
 */
-(NSArray*)allPointsForSeries:(IGPieChartView*)pieChartView;

/** Returns the original data object at a specified index.
 @param index Index of the data object to be returned.
 @return Returns the data object at a specified index.
 */
-(NSObject*)objectAtIndex:(NSInteger)index;

/** Returns the original data object based on its corresponding data point.
 @param point IGDataPoint that represents the original object.
 @param pieChartView Reference to the pie chart.
 @return Returns the data object that corresponds to the given data point.
 */
-(NSObject*)objectForDataPoint:(IGDataPoint*)point inPieChartView:(IGPieChartView*)pieChartview;
@end


/*! This class contains properties that present valuable information about a pie chart slice.
 
 This class is typically used when handling interactions, such as tap and long press gestures. It provides information, such as whether the slice is selected or exploded. It also provides the underlying data point.
 */
@interface IGPieSliceInfo : NSObject
{
    BOOL _isOthersCategory;
    NSObject *_item;
    NSInteger _index;
}
/** Determines whether the slice is selected.
 Selected slices have a distinct style and multiple slices can be selected at the same time.
 */
@property (nonatomic) BOOL isSelected;

/** Determines whether the slice is exploded.
 Exploded slices are drawn at a distance from the origin.
 */
@property (nonatomic) BOOL isExploded;

/** Determines whether the slice belongs to the Others slice. (read-only)
 Slices that belong to the Others category are not visible in the chart. They are grouped into a single slice with its own style.
 */
@property (nonatomic, readonly) BOOL isOthersCategory;

/** The underlying data object of the current slice. (read-only)
 */
@property (nonatomic, readonly) NSObject* item;

/** Returns the index of the slice. (read-only)
 */
@property (nonatomic, readonly) NSInteger index;
@end


/*! This data source helper is used to create a data source for the pie chart. 
 The data source helper provides a simplified way of supplying data for the pie chart. The resulting data structure contains multiple IGCategoryPoint instances.
 */
@interface IGPieChartViewDataSourceHelper : NSObject<IGPieChartViewDataSource>

/** An array of custom data objects. The fields in the data object are accessed via memberPath properties.
 */
@property (nonatomic, retain) NSArray* data;

/** An array of string labels used to create data points.
 */
@property (nonatomic, retain) NSArray* labels;

/** Name of the property containing labels.
 */
@property (nonatomic, retain) NSString* labelPath;

/** A numeric array of values used to create data points.
 */
@property (nonatomic, retain) NSArray* values;

/** A string value path that specifies the property in the data source used for values.
 */
@property (nonatomic, retain) NSString *valuePath;

///--------------------
///@name Initializing DataSource Helper
///--------------------

/** Initializes the data source with an array of numeric values.
 @param values Array of numeric values.
 @return Returns an initialized data source.
 */
-(id)initWithValues:(NSArray*)values;

/** Initializes the data source with an array of numeric values and string labels.
 @param values Array of numeric values.
 @param labels Array of string labels.
 @return Returns an initialized data source.
 */
-(id)initWithValues:(NSArray*)values labels:(NSArray*)labels;

/** Initializes the data source with an array of custom data objects.
 @param data Array of custom objects.
 @param valuePath The name of the property containing values.
 @return Returns an initialized data source.
 */
-(id)initWithData:(NSArray*)data valuePath:(NSString*)valuePath;

/** Initializes the data source with an array of custom data objects.
 @param data Array of custom objects.
 @param valuePath The name of the property containing values.
 @param labelPath The name of the property containing labels.
 @return Returns an initialized data source.
 */
-(id)initWithData:(NSArray*)data valuePath:(NSString*)valuePath labelPath:(NSString*)labelPath;
@end

/*! This class represents the pie chart view.
 
 The pie chart view is a data visualization tool that displays a circular graph containing sectors (slices). Pie chart data is a collection of numeric values, and each slice represents one value. Small values that fall below a user-defined threshold are grouped into the Others slice.
 
 The pie chart view supports multiple slice selection and explosion, as well as tooltips, rotation, tap and long press gestures.
 */
@interface IGPieChartView : UIView
{
    DataChartContainer *_chartContainer;
    NSMutableArray *_brushes, *_outlines;
    IGPieChartThemeDefinition *_theme;
    BOOL _isSquare;
    NSMutableArray* _dataPoints;
    NSInteger _numberOfPoints;
    IGPieSliceInfo *_selectedStyle, *_othersStyle, *_leaderLineStyle;
    IGBrush *_selectedBrush, *_selectedOutline, *_selectedLabelBrush, *_othersCategoryBrush, *_othersCategoryOutline, *_othersCategoryLabelBrush, *_leaderLineBrush;
    CGFloat _selectedStrokeThickness, _othersCategoryStrokeThickness, _leaderLineThickness;
    UIFont *_selectedLabelFont, *_othersCategoryLabelFont;
    CGFloat _originalOffsetAngle;
}

/** Sets the IGPieChartViewDelegate for the pie chart view.
 */
@property (nonatomic, assign) id<IGPieChartViewDelegate> delegate;

/** Sets the data source for the pie chart view. This can be an interface that conforms to IGPieChartViewDataSource protocol or an instance of IGPieChartViewDataSourceHelper.
 */
@property (nonatomic, assign) id<IGPieChartViewDataSource> dataSource;

/** Returns an array of IGCategoryPoint objects. (read-only)
 */
@property (nonatomic, readonly) NSMutableArray *dataPoints;

/** Determines whether exploded slices appear exploded or not.
 When set to false, this property disables all visual cues that indicate that a slice is exploded. All exploded slices will appear as not exploded. Once this property is set to true, any slices that are marked as exploded will visually appear as exploded. Changing the value of this property has no effect on the explodedSlices property.
 */
@property (nonatomic) BOOL allowSliceExplosion;

/** Determines whether selected slices appear as selected or not.
 When set to false, this property disables all visual cues that indicate that a slice is selected. All selected slices will appear as not selected. Once this property is set to true, any slices that are marked as selected will visually appear as selected. Changing the value of this property has no effect on the selectedSlices property.
 */
@property (nonatomic) BOOL allowSliceSelection;

/** An array of IGBrush objects that are used to color the pie slices. This array takes precedence over themes.
 */
@property (nonatomic, retain) NSArray* brushes;

/** An array of IGBrush objects that are used to color the slice outlines. This array takes precedence over themes.
 */
@property (nonatomic, retain) NSArray* outlines;

/** Determines how far away the tip of the slice is from the origin.
 
 This property will typically have a value between 0 and 1, where 0 would put the slice at the origin and 1 would put the tip of the slice at a distance equal to the pie's radius.
 */
@property (nonatomic) CGFloat explodedRadius;

/** Determines the font used by the pie chart labels.
 This is the default font for the labels of the slices that are not selected. Selected labels and the others label have their own font properties.
 */
@property (nonatomic, retain) UIFont *font;

/** Determines the font brush used by the pie char labels.
 This is the default font brush for the labels of the slices that are not selected. Selected labels and the others label have their own font brush properties.
 */
@property (nonatomic, retain) IGBrush *fontBrush;

/** Determines the amount of white space in the center of the chart.
 This property can be used to create an empty ring in the middle of the pie chart and make it look like a doughnut chart. The value of this property should be set between 0 and 1.
 */
@property (nonatomic) CGFloat innerExtent;

/** Determines how far the labels are displayed from the slices.
 */
@property (nonatomic) CGFloat labelExtent;

/** Determines where in the pie chart the labels are displayed.
 
 This property can be used to determine the positioning of the labels.
 Labels can be positioned in the center of the slices, inside the slices towards the outher arc, outside the slices or using best fit approach. This property can also hide the labels by setting it to IGLabelsPositionNone.
 */
@property (nonatomic) IGLabelsPosition labelsPosition;

/** Determines if the line from the slice to the label is visible.
 */
@property (nonatomic) BOOL isLeaderLineVisible;

/** The brush of the leader line.
 */
@property (nonatomic, retain) IGBrush *leaderLineBrush;

/** The thickness of the leader line.
 */
@property (nonatomic) CGFloat leaderLineThickness;

/** Associates an item legend with the pie chart.
 */
@property (nonatomic, assign) IGLegend *legend;

/** Text displayed for the Others slice. The value is "Others" by default.
 */
@property (nonatomic, retain) NSString *othersCategoryText;

/** Determines how small a value has to be in order to be grouped into the Others slice.
 */
@property (nonatomic) CGFloat othersCategoryThreshold;

/** This property is used along with othersCategoryThreshold to group slices into the Others slice. When set to IGOthersCategoryTypeNumber the value is directly compared with the threshold. When set to IGOthersCategoryTypePercent the comparison is made between the threshold and the value expressed as the percentage of the total. 
 */
@property (nonatomic) IGOthersCategoryType othersCategoryType;

/** Determines the length of the pie radius.
 
 The value of this property is multiplied by the length of the radius to produce the final radius.
 */
@property (nonatomic) CGFloat radiusFactor;

/** An index collection of selected sliced.
 
 This property contains a set of indices that represent the selected slices. For example, a set of {0,1,3} means that the first, second and fourth slices are selected.
 */
@property (nonatomic, retain) NSIndexSet *selectedSlices;

/** An index collection of exploded sliced.
 
 This property contains a set of indices that represent the exploded slices. For example, a set of {0,1,3} means that the first, second and fourth slices are exploded.
 */
@property (nonatomic, retain) NSIndexSet *explodedSlices;

/** Determines the start angle of the pie chart.
 
 This property determines the starting position of the first slice in the pie chart. The value of 0, which is the default value, starts the first slice at 3 o'clock.
 */
@property (nonatomic) CGFloat startAngle;

/** Determines whether the pie chart is clockwise or counter clockwise.
 */
@property (nonatomic) IGSweepDirection sweepDirection;

/** This property can be used to apply a theme to a pie chart.
 
 This can be a pre-defined or a custom theme.
 Pre-defined themes can be used by setting this property to one of the themes in IGPieChartDefaultThemes interface.
 */
@property (nonatomic) IGPieChartThemeDefinition *theme;

/** Specifies the tooltip location.
 
 This property determines where the tooltip will be positioned. The default setting uses a floating tooltip, which follows the location of the long press. Tooltip can also be pinned to top, bottom, left, or right.
 */
@property (nonatomic) IGTooltipPinLocation tooltipPinLocation;

/** The fill brush of the selected slice.
 */
@property (nonatomic, retain) IGBrush *selectedBrush;

/** The outline brush of the selected slice.
 */
@property (nonatomic, retain) IGBrush *selectedOutline;

/** The label brush of the selected slice.
 */
@property (nonatomic, retain) IGBrush *selectedLabelBrush;

/** The stroke thickness of the selected slice.
 */
@property (nonatomic) CGFloat selectedStrokeThickness;

/** The label font of the selected slice.
 */
@property (nonatomic, retain) UIFont *selectedLabelFont;

/** The fill brush of the Others slice.
 */
@property (nonatomic, retain) IGBrush *othersCategoryBrush;

/** The outline brush of the Others slice.
 */
@property (nonatomic, retain) IGBrush *othersCategoryOutline;

/** The label brush of the Others slice.
 */
@property (nonatomic, retain) IGBrush *othersCategoryLabelBrush;

/** The stroke thickness of the Others slice.
 */
@property (nonatomic) CGFloat othersCategoryStrokeThickness;

/** The label font of the Others slice.
 */
@property (nonatomic, retain) UIFont *othersCategoryLabelFont;

/** Determines the rendering quality of the chart.
 This property only affects retina displays. By default, the chart will render with high quality. If the chart contains too many data points and its performance begins to degrade due to a high number of shapes, setting a lower rendering quality will increase the performance.
 */
@property (nonatomic) IGRenderingQuality renderingQuality;

/** Determines the way exploded slices are rendered.
 When this property is set to IGPieSliceExplodedDisplayStyleAwayFromCenter (default) exploded slices are displaced from the origin outward. When set to IGPieSliceExplodedDisplayStyleExtendRadius exploded slices remain at the origin, but their radius is extended outward. The radius is increased by a factor of the value in explodedRadius property.
 */
@property (nonatomic) IGPieSliceExplodedDisplayStyle explodedDisplayStyle;

///----------------------
///@name Configuring the pie chart view
///----------------------

/** Rotates a slice at a given index to a specific angle position.
 @param index Index of the slice that will be rotated.
 @param angle Angle in degrees, to which the slice will be rotated.
 @param duration Duration in seconds for the rotational animation
 @param alignment Specifies which part of the slice will be aligned with the angle parameter: start of the slice, middle of the slice, end of the slice.
 */
-(void)rotateSliceWithIndex:(NSInteger)index toAngle:(CGFloat)angle duration:(NSTimeInterval)duration alignment:(IGPieChartSliceAlignment)alignment;

/** Rotates a slice representing a given data point to a specific angle position.
 @param dataPoint IGDataPoint represented by the slice that will be rotated.
 @param angle Angle in degrees, to which the slice will be rotated.
 @param duration Duration in seconds for the rotational animation
 @param alignment Specifies which part of the slice will be aligned with the angle parameter: start of the slice, middle of the slice, end of the slice.
 */
-(void)rotateSliceWithDataPoint:(IGDataPoint*)dataPoint toAngle:(CGFloat)angle duration:(NSTimeInterval)duration alignment:(IGPieChartSliceAlignment)alignment;

/** Returns a data representation of the visuals of the pie chart.
 
 This method is available to provide a way to do validation for testing of the visuals of the pie chart.
 */
- (VisualPieChartData*)exportVisualData;

///-------------------------
///@name Notifying the pie chart view of data source changes
///-------------------------

/** Notifies the chart view that all items in the data source were cleared.
 
 This method is used to tell the chart view that all of the items in a given data source have been removed.
 @param source Data source that had its items removed.
 */
-(void) clearItemsForDataSource:(id<IGPieChartViewDataSource>)source;

/** Notifies the chart view that an item has been inserted in the data source.
 
 This method is used to tell the chart view that an item has been inserted into a given data source at a given index.
 @param index Index of an item that has been inserted.
 @param source Data source that had an item inserted.
 */
-(void) insertItemAtIndex:(NSInteger)index withSource:(id<IGPieChartViewDataSource>)source;

/** Notifies the chart view that an item has been removed from the data source.
 
 This method is used to tell the chart view that an item has been removed from a given data source at a given index.
 @param index Index of an item that has been removed.
 @param source Data source that had an item removed.
 */
-(void) removeItemAtIndex:(NSInteger)index withSource:(id<IGPieChartViewDataSource>)source;

/** Notifies the chart view that an item has been replaced in the data source.
 
 This method is used to tell the chart view that an item has been replaced in a given data source at a given index.
 @param index Index of an item that has been replaced.
 @param source Data source that had an item replaced. 
 */
-(void) replaceItemAtIndex:(NSInteger)index withSource:(id<IGPieChartViewDataSource>)source;

/** Notifies the chart view that an item has been updated in the data source.
 
 This method is used to tell the chart view that an item has been updated in a given data source at a given index.
 @param index Index of an item that has been replaced.
 @param source Data source that had an item replaced.
 */
-(void)updateItemAtIndex:(NSInteger)index withSource:(id<IGPieChartViewDataSource>)source;
@end
