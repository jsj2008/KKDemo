#import "Core.h"

/*!
The linear gauge range is a filled segment that underlays the linear gauge's scale. The range is specified with a brush and a start and end values that map to the scale. Linear gauge ranges can be used as visual cues to show a break down of the scale. A linear gauge can have any number of ranges.
 */
@interface IGLinearGaugeRange : NSObject

/* Creates a new IGLinearGaugeRange object with values for start and end values.
*/
-(id)initWithStartValue:(double)startValue andEndValue:(double)endValue;

/* Creates a new IGLinearGaugeRange object with values for start and end values.  Includes the brush which should be applied for the range.
*/
-(id)initWithStartValue:(double)startValue andEndValue:(double)endValue andBrush:(IGBrush*)brush;

@property (nonatomic, retain) NSString *name;

/** Determines the brush of the range.
 */
@property (nonatomic, retain) IGBrush *brush;

/** Determines the outline of the range.
 */
@property (nonatomic, retain) IGBrush *outline;

/** Determines the start value of the range.
 */
@property (nonatomic, assign) double startValue;

/** Determines the end value of the range.
 */
@property (nonatomic, assign) double endValue;

/** Determines the end position of the inner part of the range measured from the center of the gauge.
 The value of this property should be between 0 and 1.
 */
@property (nonatomic, assign) double innerEndExtent;

/** Determines the start position of the inner part of the range measured from the center of the gauge.
 The value of this property should be between 0 and 1.
 */
@property (nonatomic, assign) double innerStartExtent;

/** Determines the end position of the outer part of the range measured from the center of the gauge.
 The value of this property should be between 0 and 1.
 */
@property (nonatomic, assign) double outerEndExtent;

/** Determines the start position of the outer part of the range measured from the center of the gauge.
 The value of this property should be between 0 and 1.
 */
@property (nonatomic, assign) double outerStartExtent;

/** Determines the thickness of the range's outline.
 */
@property (nonatomic, assign) double strokeThickness;
@end