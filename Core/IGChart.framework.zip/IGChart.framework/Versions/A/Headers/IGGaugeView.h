#import <Foundation/Foundation.h>
#import <CoreGraphics/CoreGraphics.h>
#import <UIKit/UIKit.h>
#import "Core.h"
#import "Enums.h"
#import "Themes.h"

@class IGGaugeRange;
@class VisualGaugeData;
@class IGGaugeView;

/*! This protocol has methods that provide the ability to interact with the gauge.
 */
@protocol IGGaugeViewDelegate <NSObject>
@optional
/** This method allows the user to supply an NSString that formats the label value that appears on the scale of the gauge.
 @param gaugeView Reference to the gauge.
 @param labelValue The scale value currently being processed for a label.
 @return Returns the string that will represent the supplied labelValue on the gauge scale.
 */
-(NSString *)gaugeView:(IGGaugeView *)gaugeView formatStringForValue:(double)labelValue;
@end

/*!
 IGGaugeView is a data visualization control, capable of displaying a gauge. It containis a number of visual elements, such as a scale with tickmarks and labels, a needle and a number of ranges. A scale is created by supplying minimumValue and maximumValue and a needle is created by setting value property. The needle can be set to any of the predefined shapes. The gauge also supports ranges, which provide visual cues for the scale.
 
 The gauge has a backing shape. This shape is drawn behind the scale and acts as a background for the gauge. The backing can be circular, which turns the shape into a full circle, or it can be fitted, which makes it sweep the scale.
 
 The gauge needle takes on one of the several predefined shapes. The needle can have a pivot shape, which is placed in the center of the gauge. The pivot shape also takes one of the predefined shapes. Pivot shapes that include an overlay or an underlay can have a separate pivot brush applied to the shape.
 */
@interface IGGaugeView : UIView
{
    UIControl *_container;
    NSMutableArray *_ranges;
    NSMutableArray *_rangeBrushes, *_rangeOutlines;
    id<IGGaugeThemeDefinition> _theme;
    
    UIColor *_backgroundColor;
    UIFont *_font;
    IGBrush *_backingBrush, *_backingOutline, *_fontBrush, *_minorTickBrush, *_needleBrush, *_needlePivotBrush, *_needleOutline, *_needlePivotOutline, *_scaleBrush, *_tickBrush;
}

/** Returns the resolved background color of the gauge.
 */
@property (nonatomic, readonly) UIColor *resolvedBackgroundColor;

/** Determines the brush used to fill the backing of the gauge.
 */
@property (nonatomic, retain) IGBrush *backingBrush;

/** Returns the resolved backing brush. (read-only)
 */
@property (nonatomic, readonly) IGBrush *resolvedBackingBrush;

/** Determines the corner rounding radius to use for the fitted scale backings.
 If the gauge uses a fitted backing shape, this property can be used to provide rounded corners for the backing.
 */
@property (nonatomic) CGFloat backingCornerRadius;

/** Determines the inner extent of the gauge backing. This applies only when using fitted backing shapes.
 */
@property (nonatomic) CGFloat backingInnerExtent;

/** Determines the outer extent of the gauge backing. This applies only when using fitted backing shapes.
 */
@property (nonatomic) CGFloat backingOuterExtent;

/** Determines the brush used for the outline of the backing.
 */
@property (nonatomic, retain) IGBrush *backingOutline;

/** Returns the resolved backing outline. (read-only)
 */
@property (nonatomic, readonly) IGBrush *resolvedBackingOutline;

/** Determines the over or undersweep degrees to apply to the fitted backing.
 This property can be used to add extra space and extend the backing shape past the start and end of the scale.
 */
@property (nonatomic) CGFloat backingOversweep;

/** This property can be used to set the shape of the backing of the gauge to a predefined shape.
 The backing shape can either be circular or fitted. A fitted shape creates a filled arc segment that encompasses the scale.
 */
@property (nonatomic) IGGaugeBackingShape backingShape;

/** Determines the stroke thickness for the backing outline.
 */
@property (nonatomic) CGFloat backingStrokeThickness;

/** Determines the x position of the center of the gauge with the value ranging from 0 to 1.
 */
@property (nonatomic) CGFloat centerX;

/** Determines the y position of the center of the gauge with the value ranging from 0 to 1.
 */
@property (nonatomic) CGFloat centerY;

/** Sets the interaction delegate for the linear gauge.
 */
@property (nonatomic, assign) id<IGGaugeViewDelegate> delegate;

/** Determines the behavior of overlapping first and last labels on the scale.
 If the scale wraps around in such a way that the first and the last labels align, this property can determine which of the two labels should be displayed. OmitFirst will hide the first label, OmitLast will hide the last label. OmitBoth will hide both labels and OmitNeither will show both labels and will let them collide.
 */
@property (nonatomic) IGGaugeDuplicateLabelOmissionStrategy duplicateLabelOmissionStrategy;

/** Determines the font used by the gauge scale labels.
 */
@property (nonatomic, retain) UIFont *font;

/** Returns the resolved label font. (read-only)
 */
@property (nonatomic, readonly) UIFont *resolvedFont;

/** Determines the font brush used by the gauge scale labels.
 */
@property (nonatomic, retain) IGBrush *fontBrush;

/** Returns the resolved font brush. (read-only)
 */
@property (nonatomic, readonly) IGBrush *resolvedFontBrush;

/** Determines the interval used by the scale.
 */
@property (nonatomic) CGFloat interval;

/** Determines the label position as a value between 0 and 1 from the center of the gauge.
 Setting labelExtent to 0 will place all the labels at the center of the gauge, while setting it to 1 will place them at radius.
 */
@property (nonatomic) CGFloat labelExtent;

/** Determines the interval to use for rendering labels. This defaults to the same interval as the tickmarks on the scale.
 */
@property (nonatomic) CGFloat labelInterval;

/** Determines the maximum value of the scale.
 */
@property (nonatomic) CGFloat maximumValue;

/** Determines the minimum value of the scale.
 */
@property (nonatomic) CGFloat minimumValue;

/** Determines the brush used for the minor tickmarks.
 */
@property (nonatomic, retain) IGBrush *minorTickBrush;

/** Returns the resolved minor tickmark brush. (read-only)
 */
@property (nonatomic, readonly) IGBrush *resolvedMinorTickBrush;

/** Determines the number of tickmarks to place between two major tickmarks.
 */
@property (nonatomic) CGFloat minorTickCount;

/** Determines the position at which to stop rendering the minor tickmarks as a value from 0 to 1, measured from the center of the gauge.
 Values greater than 1 can be used to make this extend further than the normal radius of the gauge.
 */
@property (nonatomic) CGFloat minorTickEndExtent;

/** Determines the position at which to start rendering the minor tickmarks as a value from 0 to 1, measured from the center of the gauge.
 Values greater than 1 can be used to make this extend further than the normal radius of the gauge.
 */
@property (nonatomic) CGFloat minorTickStartExtent;

/** Determines the thickness of minor tickmarks.
 */
@property (nonatomic) CGFloat minorTickStrokeThickness;

/** Determines the extent of the feature that is closest to the base (e.g. a bulb).
 The feature can only be placed between the tail of the needle and the pivot, so this property should have a value that is less than 0. The feature will be hidden if it intersects the needle's pivot shape. Only needle shapes that have a bulb respect this property.
 */
@property (nonatomic) CGFloat needleBaseFeatureExtent;

/** Determines the width of the needle at its feature that is closest to the base (e.g. a bulb).
 The value of this property should be between 0 and 1. Only needle shapes that have a bulb respect this property.
 */
@property (nonatomic) CGFloat needleBaseFeatureWidthRatio;

/** Determines the brush of the gauge needle.
 */
@property (nonatomic,retain) IGBrush *needleBrush;

/** Returns the resolved needle brush. (read-only)
 */
@property (nonatomic, readonly) IGBrush *resolvedNeedleBrush;

/** Determines the fill brush for the needle pivot shape.
 This pivot brush only applies to the pivot shapes that draw an overlay or an underlay. Otherwise, this setting has no effect on the pivot shape.
 */
@property (nonatomic, retain) IGBrush *needlePivotBrush;

/** Returns the resolved needle pivot shape brush. (read-only)
 */
@property (nonatomic, readonly) IGBrush *resolvedNeedlePivotBrush;

/** Determines the width of the inner cutout section of the needle pivot shape.
 The value of this property should be between 0 and 1. This will only take effect if the needle has a pivot set that has a cutout section.
 */
@property (nonatomic) CGFloat needlePivotInnerWidthRatio;

/** Determines the brush used by the outlines of the needle pivot shape.
 This pivot brush only applies to the pivot shapes that draw an overlay or an underlay. Otherwise, this setting has no effect on the pivot shape.
 */
@property (nonatomic, retain) IGBrush *needlePivotOutline;

/** Returns the resolved needle pivot shape outline. (read-only)
 */
@property (nonatomic, readonly) IGBrush *resolvedNeedlePivotOutline;

/** Determines the pivot shape to use for the needle.
 */
@property (nonatomic) IGGaugePivotShape needlePivotShape;

/** Determines the stroke thickness of the needle pivot's outline.
 */
@property (nonatomic) CGFloat needlePivotStrokeThickness;

/** Determines the width of the needle pivot shape. 
 The value of this property should be between 0 and 1. Only takes effect when a pivot is set on the needle.
 */
@property (nonatomic) CGFloat needlePivotWidthRatio;

/** Determines the end extent of the needle, measured from the center of the gauge.
 The value of this property should be between -1 and 1.
 */
@property (nonatomic) CGFloat needleEndExtent;

/** Determines the width of the needle at its point.
 The value of this property should be between 0 and 1.
 */
@property (nonatomic) CGFloat needleEndWidthRatio;

/** Determines the brush used by the outline of the needle.
 */
@property (nonatomic, retain) IGBrush *needleOutline;

/** Returns the resolved needle outline. (read-only)
 */
@property (nonatomic, readonly) IGBrush *resolvedNeedleOutline;

/** Determines the extent of the feature closest to the point (e.g. the tapering point of a needle).
 The value of this property should be between -1 and 1. Only some needle shapes respect this property.
 */
@property (nonatomic) CGFloat needlePointFeatureExtent;

/** Determines the width of the needle at its feature closest to the point (e.g. the tapering point of a needle).
 The value of this property should be between 0 and 1. Only some needle shapes respect this property.
 */
@property (nonatomic) CGFloat needlePointFeatureWidthRatio;

/** This property can be used to set one of the predefined shapes for the needle.
 */
@property (nonatomic) IGGaugeNeedleShape needleShape;

/** Determines the start extent of the needle, measured from the center of the gauge.
 The value of this property should be between -1 and 1.
 */
@property (nonatomic) CGFloat needleStartExtent;

/** Determines the width of the needle at its point.
 The value of this property should be between 0 and 1.
 */
@property (nonatomic) CGFloat needleStartWidthRatio;

/** Detemines the stroke thickness of the needle's outline.
 */
@property (nonatomic) CGFloat needleStrokeThickness;

/** Returns an array of ranges in the current gauge.
 */
@property (nonatomic, readonly) NSArray *ranges;

/** Determines the brush palette used by the gauge ranges.
 */
@property (nonatomic, retain) NSArray *rangeBrushes;

/** Returns a resolved brush palette used by the gauge ranges.
 */
@property (nonatomic, readonly) NSArray *resolvedRangeBrushes;

/** Determines the brush palette used by the gauge range outlines.
 */
@property (nonatomic, retain) NSArray *rangeOutlines;

/** Returns a resolved brush palette used by the gauge range outlines.
 */
@property (nonatomic, readonly) NSArray *resolvedRangeOutlines;

/** Determines the multiplying factor to apply to the normal radius of the gauge.
 The normal radius of the gauge is defined by the minimum of the width and height of the control divided by 2.0.
 */
@property (nonatomic) CGFloat radiusMultiplier;

/** Determines the brush used to fill the background of the scale.
 */
@property (nonatomic, retain) IGBrush *scaleBrush;

/** Returns the resolved scale brush. (read-only)
 */
@property (nonatomic, readonly) IGBrush *resolvedScaleBrush;

/** Determines the end angle for the scale in degrees.
 */
@property (nonatomic) CGFloat scaleEndAngle;

/** Determines the end position of the scale measured from the center of the gauge.
 The value of this property should be between 0 and 1.
 */
@property (nonatomic) CGFloat scaleEndExtent;

/** Determines the amount of extra space (in degrees) the scale will oversweep in both directions from the start and end values. This value must be greater than 0. The default value is 3.
 */
@property (nonatomic) CGFloat scaleOversweep;

/** Determines the amount of oversweep applied to the scale's backing.
 The default value is Auto, which uses a circular shape for a circular backing and a fitted shape for a fitted backing.
 */
@property (nonatomic) IGGaugeScaleOversweepShape scaleOversweepShape;

/** Determines the start angle for the scale in degrees.
 */
@property (nonatomic) CGFloat scaleStartAngle;

/** Determines the start position of the scale measured from the center of the gauge.
 The value of this property should be between 0 and 1.
 */
@property (nonatomic) CGFloat scaleStartExtent;

/** Determines whether the scale sweeps clockwise or counterclockwise.
 */
@property (nonatomic) IGSweepDirection scaleSweepDirection;

/** Determines the brush of major tickmarks.
 This property is used to change the brush of the major tickmarks of the gauge scale. In order to change the brush of the minor tickmarks, use minorTickBrush property.
 */
@property (nonatomic, retain) IGBrush *tickBrush;

/** Returns the resolved major tickmark brush. (read-only)
 */
@property (nonatomic, readonly) IGBrush *resolvedTickBrush;

/** Determines the end position of major tickmarks measured from the center of the gauge.
 The value of this property should be between 0 and 1 and affects major tickmarks only. To change the extent of minor tickmarks, use minorTickEndExtent
 */
@property (nonatomic) CGFloat tickEndExtent;

/** Determines the start position of major tickmarks measured from the center of the gauge.
 The value of this property should be between 0 and 1 and affects major tickmarks only. To change the extent of minor tickmarks, use minorTickStartExtent.
 */
@property (nonatomic) CGFloat tickStartExtent;

/** Determines the stroke thickness of the major tickmarks.
 */
@property (nonatomic) CGFloat tickStrokeThickness;

/** Determines the number of seconds over which the gauge should be animated.
 */
@property (nonatomic) NSTimeInterval transitionDuration;

/** An object that defines a set of brushes and fonts that will be used to style the gauge.
 */
@property (nonatomic, assign) id<IGGaugeThemeDefinition> theme;

/** Determines the value, at which to point the needle of the gauge.
 */
@property (nonatomic) CGFloat value;

///----------------------
///@name Configuring the gauge view
///----------------------

/** Removes all ranges from the gauge view.
 */
-(void)clearRanges;

/** Adds a range to the gauge view.
 @param range Range to be added to the gauge view.
 */
-(void)addRange:(IGGaugeRange*)range;

/** Inserts a range into a gauge view at a specified index.
 @param range Range to be inserted into a gauge view.
 @param index Index at which the range will be inserted.
 */
-(void)insertRange:(IGGaugeRange*)range atIndex:(NSInteger)index;

/** Removes a specified range from the gauge view.
 @param range Range to be removed from the gauge view.
 */
-(void)removeRange:(IGGaugeRange*)range;

/** Returns a data representation of the visuals of the gauge.
 
 This method is available to provide a way to do validation for testing of the visuals of the gauge.
 */
- (VisualGaugeData*)exportVisualData;

///----------------------
///@name Interacting with the Gauge
///----------------------

/** Given a point on the gauge view, a value is returned. 
 
 Note: If a point is given where there is an no valid value, a value less than the minimumValue will be returned.
 
 @param point A location inside of the gauge.
 */
-(CGFloat)valueForPoint:(CGPoint)point;

/** Returns whether the needle exists at a specified point.

 @param point A location inside of the gauge.
 */
-(BOOL)needleAtPoint:(CGPoint)point;

@end


/*! 
 The gauge range is a filled arc segment that overlays the gauge's scale. The range is specified with a brush and a start and end values that map to the scale.
 Gauge ranges can be used as visual cues to show a break down of the scale. A gauge can have any number of ranges.
 */
@interface IGGaugeRange : NSObject
/** Determines the brush of the gauge range.
 */
@property (nonatomic, retain) IGBrush *brush;

/** Determines the end value of the gauge range.
 */
@property (nonatomic) CGFloat endValue;

/** Determines the end position of the inner part of the range measured from the center of the gauge.
 The value of this property should be between 0 and 1.
 */
@property (nonatomic) CGFloat innerEndExtent;

/** Determines the start position of the inner part of the range measured from the center of the gauge.
 The value of this property should be between 0 and 1.
 */
@property (nonatomic) CGFloat innerStartExtent;

/** Determines the end position of the outer part of the range measured from the center of the gauge.
 The value of this property should be between 0 and 1.
 */
@property (nonatomic) CGFloat outerEndExtent;

/** Determines the start position of the outer part of the range measured from the center of the gauge.
 The value of this property should be between 0 and 1.
 */
@property (nonatomic) CGFloat outerStartExtent;

/** Determines the outline of the gauge range.
 */
@property (nonatomic, retain) IGBrush *outline;

/** Determines the start value of the gauge range.
 */
@property (nonatomic) CGFloat startValue;

/** Determines the thickness of the range's outline.
 */
@property (nonatomic) CGFloat strokeThickness;
@end
