#import <UIKit/UIKit.h>
#import "IGTreemapView.h"

@class IGTreemapView;
@class IGBrush;

/*!
 IGTreemapNode is a view that displays the treemap's hierarchy. The treemap's root is a node and all of nodes' children are nodes, as well.
 Each node is represented by a rectangle with an optional label and can have any number of children. A node has a single numeric value used for its size.
 */
@interface IGTreemapNode : UIView

/** An array of child nodes. Each child node must be an IGTreemapNode.
 */
@property (nonatomic, retain) NSArray *children;

/** Reference to the parent node.
 */
@property (nonatomic, weak) IGTreemapNode *parent;

/** Reference to the treemap view.
 */
@property (nonatomic, weak) IGTreemapView *treemap;

/** Specifies the node's value used to determine the size of the node.
 */
@property (nonatomic) CGFloat value;

/** Returns the node's scaled value as a ratio of the node's value to the values of its siblings.
 */
@property (nonatomic, readonly) CGFloat weightedValue;

/** Returns the level of depth of the node in the treemap's hierarchy.
 */
@property (nonatomic) NSInteger level;

/** Returns whether or not the node is the root node of the treemap.
 */
@property (nonatomic, readonly) BOOL isRootNode;

/** Determines the amount of padding in pixels around the node.
 */
@property (nonatomic) CGRect padding;

/** Returns the actual padding around the node.
 */
@property (nonatomic, readonly) CGRect resolvedPadding;

/** Determines the string label of the node.
 */
@property (nonatomic, copy) NSString *label;

/** Data object that the node was created from.
 */
@property (nonatomic, retain) NSObject *sourceItem;

/** Data objects that are used to create child nodes.
 */
@property (nonatomic, retain) NSObject *dataContext;

/** The bounds rectangle of the node.
 */
@property (nonatomic) CGRect nodeBounds;

/** Determines the amount of space reserved for the label at the top of the node.
 */
@property (nonatomic) CGFloat headerHeight;

/** Returns the actual amount of space used by the node for its label.
 */
@property (nonatomic, readonly) CGFloat resolvedHeaderHeight;

/** Determines the amount of space between the label and the edge of the node.
 */
@property (nonatomic) CGFloat labelPadding;

/** Returns the actual amount of padded space before the label.
 */
@property (nonatomic, readonly) CGFloat resolvedLabelPadding;

/** A unique node identifier. 
 */
@property (nonatomic, copy) NSString *nodeId;

/** Returns the actual size of the node.
 */
@property (nonatomic, readonly) CGSize finalSize;

/** Determines the fill brush of the node.
 This property will take precedence over treemap themes, color mapper, and brushes property.
 */
@property (nonatomic, retain) IGBrush *brush;

/** Determines the outline (border) brush of the node.
 This property will take precedence over treemap themes and outlines property.
 */
@property (nonatomic, retain) IGBrush *outline;

/** Determines the thickness of the node's outline.
 This property will take precedence over any properties set on the treemap level.
 */
@property (nonatomic) CGFloat outlineThickness;

/** Returns the actual fill brush of the node.
 */
@property (nonatomic, readonly) IGBrush *resolvedBrush;

/** Returns the actual outline brush of the node.
 */
@property (nonatomic, readonly) IGBrush *resolvedOutline;

/** Returns the actual outline thickness of the node.
 */
@property (nonatomic, readonly) CGFloat resolvedOutlineThickness;
@end
