//
//  IGLegend.h
//
//  Copyright (c) 2012 Infragistcs. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "Enums.h"
#import "Core.h"
#import "Themes.h"

@class DataChartContainer;

typedef enum {
    IGChartLegendTypeSeries,
    IGChartLegendTypeItem
} IGChartLegendType;

/*!
 This is the base class for the chart legend. This class should not be allocated.
 */
@interface IGLegendBase : UIView

/** Initializes and returns a lgend view object for displaying a specific legend type.
 
 @param legendType Whether the legend should be used for displaying items of a series, or an item per series.
 @return Returns an initialized IGLegend object or nil if the object could not be successfully initialized.
 */
-(id)initWithLegendType:(IGChartLegendType)legendType;

/** Initializes and returns a lgend view object with a set frame for displaying a specific legend type.
 
 @param frame Size of the legend.
 @param legendType Whether the legend should be used for displaying items of a series, or an item per series.
 @return Returns an initialized IGLegend object or nil if the object could not be successfully initialized.
 */
-(id)initWithFrame:(CGRect)frame andLegendType:(IGChartLegendType)legendType;

/** The size of each legend item's badge
*/
@property(nonatomic, assign) CGSize badgeSize;

/** The theme to be used to style items
 */
@property(nonatomic, readonly) IGChartThemeDefinitionBase* theme;

/** Whether the legend should be used to display a different legend item for each series, or for each item in  a series.
 */
@property(nonatomic, readonly)IGChartLegendType legendType;

/** ONLY TO BE USED IN DERIVED CLASS
 
    Allows a custom legend to build up a view with new items.
 */
-(void)buildItemViews:(NSMutableArray*)items;

/** ONLY TO BE USED IN DERIVED CLASS
 
 Notifies a custom legend that it might need to update its layout. 
 */
-(void)updateItems;

@end


/*!
 IGLegend is a UIView that displays information about chart view's series. This type of legend is the most common and can be used by all series types. The legend displays rows of legend items, with each legend item consisting of an icon and a label. The icon represents the brush of the series associated with the legend item and the label is the title of the series. The legend can be used to display series from multiple charts. When multiple chart views set their legend property to the same legend, all series from those chart views will be displayed in that legend. The legend can also be set from the series. Doing so will take precedence over chart view's legend property. With this legend, one series will display only one legend item. When the series does not have a title set, "Series Title" will be used in the legend item.
 */
@interface IGLegend : IGLegendBase


/* Orientation of the legend view.
 This property determines whether the legend draws its items vertically or horizontally.
 */
@property (nonatomic, assign) IGOrientation orientation;

/** Horizontal alignment of the legend items.
 */
@property(nonatomic, assign) IGHorizontalAlign horizontalAlignment;

/** Vertical alignment of the legend items.
 */
@property(nonatomic, assign) IGVerticalAlign verticalAlignment;

@end

/*!
 IGLegendItem is a non visual object that tracks the item that is going to be displayed in the legend of a chart.  
 */
@interface IGLegendItem : NSObject

/** The visual badge for a legend item.
 */
@property(nonatomic, retain)UIImage* badge;

/** The display text for a legend item.
 */
@property(nonatomic, retain)NSString* title;

@end

