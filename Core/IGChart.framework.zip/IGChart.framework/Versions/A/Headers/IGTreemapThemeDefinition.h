#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "Core.h"
/*!
 This protocol contains properties that allow customized themes for the treemap.
 */
@protocol IGTreemapThemeDefinition<NSObject>
@optional
/*!
 An array of brushes applied to the treemap levels.
 */
@property (nonatomic, readonly) NSArray *brushes;
/*!
 An array of brushes applied to the borders around treemap nodes at different levels.
 */
@property (nonatomic, readonly) NSArray *outlines;
/*!
 The UIFont that would be applied to the control.
 */
@property (nonatomic, readonly) UIFont *font;
/*!
 The IGBrush that would be applied to the font of the control.
 */
@property (nonatomic, readonly) IGBrush *fontBrush;
/*!
 Specifies a string name for the current theme.
 */
@property (nonatomic, readonly) NSString *name;
@end