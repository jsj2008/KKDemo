#import <Foundation/Foundation.h>
#import "Core.h"

/*!
 This class represents a palette item used by the chartView's themes. It contains a pair of brushes for the fill and the stroke of a shape.
 */
@interface IGChartPaletteItem : NSObject {    
    IGBrush* _color;
    IGBrush* _outlineColor;
    NSString *_name;
}

/** Determines the fill brush of a palette item.
 */
@property (nonatomic, retain) IGBrush* color;

/** Determines the stroke brush of a palette item.
 */
@property (nonatomic, retain) IGBrush* outlineColor;

/** Specifies a string name for the current palette item.
 */
@property (nonatomic, retain) NSString *name;
@end

/*!
 A base class for all chart based theme definitions.  It contains default properties which all chart themes would find useful.
 */
@interface IGChartThemeDefinitionBase : NSObject
{
    UIFont* _font;
    IGBrush* _fontColor;
    UIColor *_backgroundColor;
    UIFont* _legendFont;
    IGBrush* _legendFontColor;
    IGChartPaletteItem* _legendPalette;
    CGFloat _legendBorderThickness;
    NSString *_name;
}

/*!
 The UIFont which should be applied to the main control's font property.
 */
@property (nonatomic, retain) UIFont* font;

/*!
 The IGBrush which should be applied to the main control's font property.
 */
@property (nonatomic, retain) IGBrush* fontColor;

/*!
 The UIColor which should be applied to the main control's backgroundColor.
 */
@property (nonatomic, retain) UIColor *backgroundColor;

/*!
 The UIFont which should be applied to the legend control's font property.
 */
@property (nonatomic, retain) UIFont* legendFont;

/*!
 The IGBrush which should be applied to the legend control's font property.
 */
@property (nonatomic, retain) IGBrush* legendFontColor;

/*!
 The IGChartPaletteItem which will define the colors used by the legend.
 */
@property (nonatomic, retain) IGChartPaletteItem* legendPalette;

/*!
 The value that will be applied to the border thickness property of the legend.
 */
@property (nonatomic) CGFloat legendBorderThickness;

/*!
 A name so that the theme can be identified.
 */
@property (nonatomic, retain) NSString *name;
@end

/*!
 A base class for IGChartView themes which adds properties to the IGChartThemeDefinitionBase which will better support the IGChartView.
 */
@interface IGChartThemeDefinition : IGChartThemeDefinitionBase {
    NSMutableArray* _seriesPalette;
    IGChartPaletteItem* _axisPalette;
}
/*!
 The NSMutableArray of palettes which can be applied to the series in the control.
 */
@property (readonly, nonatomic) NSMutableArray* seriesPalettes;
/*!
 The IGChartPaletteItem which should be appied to the axis of the control.
 */
@property (nonatomic, retain) IGChartPaletteItem* axisPalette;

/** Determines the brush of the chart's plot area.
 The chart's plot area is the area where the series and the axis gridlines are displayed. The plot area does not include axis label panels.
 */
@property (nonatomic, retain) IGChartPaletteItem *plotAreaPalette;
@end

/*!
 A base class for IGPieChartView themes which adds properties to the IGChartThemeDefinitionBase which will better support the IGPieChartView.
 */
@interface IGPieChartThemeDefinition : IGChartThemeDefinitionBase
{
    NSMutableArray *_slicePalettes;
}
/*!
 The NSMutableArray of palettes which can be applied to the slices in the control.
 */
@property (nonatomic, readonly) NSMutableArray *slicePalettes;
/*!
 The IGChartPaletteItem which should be appied to the selected slices in the control.
 */
@property (nonatomic, retain) IGChartPaletteItem *selectedPalette;
/*!
 The UIFont that would be applied to the selected slices in the control.
 */
@property (nonatomic, retain) UIFont *selectedFont;
/*!
 The value that will be to the selected slices in the control.
 */
@property (nonatomic) CGFloat selectedThickness;
/*!
 The IGBrush that would be applied to the font on the selected slices in the control.
 */
@property (nonatomic, retain) IGBrush *selectedFontColor;
/*!
 The IGChartPaletteItem which should be appied to the other category slice in the control.
 */
@property (nonatomic, retain) IGChartPaletteItem *othersCategoryPalette;
/*!
 The UIFont that would be applied to the other category slice in the control.
 */
@property (nonatomic, retain) UIFont *othersCategoryFont;
/*!
 The value that will be to the other category slice in the control.
 */
@property (nonatomic) CGFloat othersCategoryThickness;
/*!
 The IGBrush that would be applied to the font on the other category slice in the control.
 */
@property (nonatomic, retain) IGBrush *othersCategoryFontColor;
/*!
 The IGChartPaletteItem which should be appied to the leader line in the control.
 */
@property (nonatomic, retain) IGChartPaletteItem *leaderLinePalette;
/*!
 The value that will be to the leader line in the control.
 */
@property (nonatomic) CGFloat leaderLineThickness;
@end


/*!
 This class defines properties that can be used to customize the appearance of IGFunnelChartView.
 */
@protocol IGFunnelChartThemeDefinition<NSObject>
@optional
/*!
 An array of brushes applied to the slices. This does not affect selected slices.
 */
@property (nonatomic, readonly) NSArray *brushes;

/*!
 An array of brushes applied to the borders around slices. This does not affect selected slices.
 */
@property (nonatomic, readonly) NSArray *outlines;

/*!
 Thickness of the outline around the slices.
 */
@property (nonatomic, readonly) CGFloat outlineThickness;

/*! 
 The brush applied to the selected slices.
 */
@property (nonatomic, readonly) IGBrush *selectedBrush;

/*!
 The brush applied to the borders around selected slices.
 */
@property (nonatomic, readonly) IGBrush *selectedOutline;

/*!
 Thickness of the outline around the selected slices.
 */
@property (nonatomic, readonly) CGFloat selectedOutlineThickness;

/*!
 Fill opacity of the selected slices.
 */
@property (nonatomic, readonly) CGFloat selectedOpacity;

/*!
 The UIFont applied to the inner and outer labels of the funnel.
 */
@property (nonatomic, readonly) UIFont *font;

/*!
 The brush applied to the inner and outer labels of the funnel.
 */
@property (nonatomic, readonly) IGBrush *fontBrush;

/*!
 The UIFont which should be applied to the legend control's font property.
 */
@property (nonatomic, readonly) UIFont* legendFont;

/*!
 The IGBrush which should be applied to the legend control's font property.
 */
@property (nonatomic, readonly) IGBrush* legendFontColor;

/*!
 The IGChartPaletteItem which will define the colors used by the legend.
 */
@property (nonatomic, readonly) IGChartPaletteItem* legendPalette;

/*!
 The UIColor applied to the background of the funnel.
 */
@property (nonatomic, readonly) UIColor *backgroundColor;

/*!
 Specifies a string name for the current theme.
 */
@property (nonatomic, readonly) NSString *name;
@end

/*!
 A base class for IGGaugeView themes which adds properties which will better support the IGGaugeView.
 */
@protocol IGGaugeThemeDefinition<NSObject>
@optional
/*!
 The NSMutableArray of IGBrush objects which can be applied to the ranges in the control.
 */
@property (nonatomic, readonly) NSArray *rangeBrushes;
/*!
 The NSMutableArray of outlines which can be applied to the ranges in the control.
 */
@property (nonatomic, readonly) NSArray *rangeOutlines;
/*!
 The UIFont that would be applied to the control.
 */
@property (nonatomic, readonly) UIFont *font;
/*!
 The IGBrush that would be applied to the font of the control.
 */
@property (nonatomic, readonly) IGBrush *fontBrush;
/*!
 The UIColor that would be applied to the backgroundColor of the control.
 */
@property (nonatomic, readonly) UIColor *backgroundColor;
/*!
 The IGBrush that would be applied to the scaleBrush of the control.
 */
@property (nonatomic, readonly) IGBrush *scaleBrush;
/*!
 The IGBrush that would be applied to the needleBrush of the control.
 */
@property (nonatomic, readonly) IGBrush *needleBrush;
/*!
 The IGBrush that would be applied to the needleOutline of the control.
 */
@property (nonatomic, readonly) IGBrush *needleOutline;
/*!
 The IGBrush that would be applied to the backingBrush of the control.
 */
@property (nonatomic, readonly) IGBrush *backingBrush;
/*!
 The IGBrush that would be applied to the backingOutline of the control.
 */
@property (nonatomic, readonly) IGBrush *backingOutline;
/*!
 The IGBrush that would be applied to the minorTickBrush of the control.
 */
@property (nonatomic, readonly) IGBrush *minorTickBrush;
/*!
 The IGBrush that would be applied to the majorTickBrush of the control.
 */
@property (nonatomic, readonly) IGBrush *majorTickBrush;
/*!
 The IGBrush that would be applied to the needlePivotBrush of the control.
 */
@property (nonatomic, readonly) IGBrush *needlePivotBrush;
/*!
 The IGBrush that would be applied to the needlePivotOutline of the control.
 */
@property (nonatomic, readonly) IGBrush *needlePivotOutline;
/*!
 Specifies a string name for the current theme.
 */
@property (nonatomic, readonly) NSString *name;
@end

/*!
 A base class for IGBulletGraph themes which adds properties which will better support the IGBulletGraph
 */
@protocol IGBulletGraphThemeDefinition<NSObject>

@optional

/* The UIColor that will be assigned to the controls backgroundColor*/
@property (nonatomic, readonly) UIColor *backgroundColor;


@property (nonatomic, readonly) IGBrush* valueBrush;
@property (nonatomic, readonly) IGBrush* valueOutlineBrush;
@property (nonatomic, readonly) IGBrush* backingBrush;
@property (nonatomic, readonly) IGBrush* backingOutlineBrush;
@property (nonatomic, readonly) IGBrush* fontBrush;
@property (nonatomic, readonly) IGBrush* minorTickBrush;
@property (nonatomic, readonly) IGBrush* targetValueBrush;
@property (nonatomic, readonly) IGBrush* targetValueOutlineBrush;
@property (nonatomic, readonly) IGBrush* tickBrush;
@property (nonatomic, readonly) NSString* name;
@property (nonatomic, readonly) UIFont* font;

@property (nonatomic,readonly)NSArray* rangeBrushes;

@end

/*!
 A base class for IGLinearGaugeView themes which adds properties that will better support the IGLinearGaugeView
 */
@protocol IGLinearGaugeThemeDefinition<NSObject>

@optional

/* The UIColor that will be assigned to the controls backgroundColor.
 */
@property (nonatomic, readonly) UIColor *backgroundColor;

/** The IGBrush used to fill the backing of the linear gauge.
 */
@property (nonatomic, readonly) IGBrush *backingBrush;

/** The IGBrush used for the outline of the backing.
 */
@property (nonatomic, readonly) IGBrush *backingOutlineBrush;

/** The UIFont used by the scale labels.
 */
@property (nonatomic, readonly) UIFont *font;

/** The font IGBrush used by the scale labels.
 */
@property (nonatomic, readonly) IGBrush *fontBrush;

/** The IGBrush used for the minor tickmarks.
 */
@property (nonatomic, readonly) IGBrush *minorTickBrush;

/** The name for the current theme.
*/
@property (nonatomic, readonly) NSString *name;

/** The IGBrush of the linear gauge needle.
 */
@property (nonatomic, readonly) IGBrush *needleBrush;

/** The IGBrush used by the outline of the needle.
 */
@property (nonatomic, readonly) IGBrush *needleOutlineBrush;

/*!
 The NSMutableArray of IGBrush objects which can be applied to the ranges in the control.
 */
@property (nonatomic, readonly) NSArray *rangeBrushes;
/*!
 The NSMutableArray of outlines which can be applied to the ranges in the control.
 */
@property (nonatomic, readonly) NSArray *rangeOutlines;

/** The IGBrush used to fill the background of the scale.
 */
@property (nonatomic, readonly) IGBrush *scaleBrush;

/** The IGBrush to use for the outline of the scale.
*/
@property (nonatomic, readonly) IGBrush *scaleOutlineBrush;

/** The IGBrush of major tickmarks.
 */
@property (nonatomic, readonly) IGBrush *tickBrush;

@end

/*!
 A base class for IGSparklineView themes which adds properties which will better support the IGSparklineView.
 */
@protocol IGSparklineThemeDefinition<NSObject>
@optional

/*! The IGBrush which all will be used for positive values */
@property (nonatomic, readonly) IGBrush *brush;

/*! The IGBrush which will be used when rendering negative values. */
@property (nonatomic, readonly) IGBrush *negativeBrush;

/*! The IGBrush which will be used for positive value markers. */
@property (nonatomic, readonly) IGBrush *markerBrush;

/* The IGBrush which will be used for negative value markers. */
@property (nonatomic, readonly) IGBrush *negativeMarkerBrush;

/* The IGBrush which will be used for the first rendered marker. */
@property (nonatomic, readonly) IGBrush *firstMarkerBrush;

/* The IGBrush which will be used for the last rendered marker.*/
@property (nonatomic, readonly) IGBrush *lastMarkerBrush;

/* The IGBrush which will be used for the highest value marker rendered. */
@property (nonatomic, readonly) IGBrush *highMarkerBrush;

/* The IGBrush which will be used for the lowest value marker rendered. */
@property (nonatomic, readonly) IGBrush *lowMarkerBrush;

/* The IGBrush which will be used for the trendline. */
@property (nonatomic, readonly) IGBrush *trendLineBrush;

/* The IGBrush which will be used for the horizontal axis lines. */
@property (nonatomic, readonly) IGBrush *horizontalAxisBrush;

/* The IGBrush which will be used for the vertical axis lines. */
@property (nonatomic, readonly) IGBrush *verticalAxisBrush;

/* The UIColor that will be assigned to the controls backgroundColor*/
@property (nonatomic, readonly) UIColor *backgroundColor;

/* The UIFont that will be applied to the labels.*/
@property (nonatomic,readonly) UIFont *font;

/*The thickness for the threndline*/
@property (nonatomic, readonly) CGFloat trendlineThickness;

/*!
 Specifies a string name for the current theme.
 */
@property (nonatomic, readonly) NSString *name;
@end


@protocol IGRangeSelectorThemeDefinition <NSObject>

@optional

@property (nonatomic,readonly) UIView* maximumThumbView;
@property (nonatomic,readonly) UIView* minimumThumbView;
@property (nonatomic,readonly) UIView* thumbView;
@property (nonatomic,readonly) UIColor* shadeColor;


@end

/*!
 IGChartDefaultThemes is an object that hosts static methods which produce the default themes provided for the IGChartView.
 */
@interface IGChartDefaultThemes : NSObject
+(IGChartThemeDefinition*)DefaultTheme;
+(IGChartThemeDefinition*)IGTheme;
+(IGChartThemeDefinition*)IGThemeDark;
+(IGChartThemeDefinition*)DarkTheme1;
+(IGChartThemeDefinition*)DarkTheme2;
+(IGChartThemeDefinition*)DarkTheme3;
+(IGChartThemeDefinition*)DarkTheme4;
@end

/*!
 IGChartGradientThemes is an object that hosts static methods which produce the default gradient based themes provided for the IGChartView.
 */
@interface IGChartGradientThemes : NSObject
+(IGChartThemeDefinition*)IGTheme;
+(IGChartThemeDefinition*)IGThemeDark;
+(IGChartThemeDefinition*)FinanceTheme1;
+(IGChartThemeDefinition*)FinanceTheme2;
+(IGChartThemeDefinition*)FinanceTheme3;
+(IGChartThemeDefinition*)FinanceTheme4;
+(IGChartThemeDefinition*)FinanceTheme5;
@end

/*!
    IGPieChartDefaultThemes is an object that hosts static methods which produce the default themes provided for the IGPieChartView.
 */
@interface IGPieChartDefaultThemes : NSObject
+(IGPieChartThemeDefinition*)DefaultTheme;
+(IGPieChartThemeDefinition*)IGTheme;
+(IGPieChartThemeDefinition*)IGThemeDark;
+(IGPieChartThemeDefinition*)DarkTheme1;
+(IGPieChartThemeDefinition*)DarkTheme2;
+(IGPieChartThemeDefinition*)DarkTheme3;
+(IGPieChartThemeDefinition*)DarkTheme4;
@end

/*!
 IGPieChartGradientThemes is an object that hosts static methods which produce the default gradient based themes provided for the IGPieChartView.
 */
@interface IGPieChartGradientThemes : NSObject
+(IGPieChartThemeDefinition*)IGTheme;
+(IGPieChartThemeDefinition*)IGThemeDark;
+(IGPieChartThemeDefinition*)FinanceTheme1;
+(IGPieChartThemeDefinition*)FinanceTheme2;
+(IGPieChartThemeDefinition*)FinanceTheme3;
+(IGPieChartThemeDefinition*)FinanceTheme4;
+(IGPieChartThemeDefinition*)FinanceTheme5;
@end

/*!
 Default funnel chart theme.
 */
@interface IGFunnelChartDefaultTheme : NSObject<IGFunnelChartThemeDefinition>
@end

/*!
 Infragistics theme for the funnel chart.
 */
@interface IGFunnelChartIGTheme : NSObject<IGFunnelChartThemeDefinition>
@end

/*!
 Infragistics dark theme for the funnel chart.
 */
@interface IGFunnelChartIGThemeDark : NSObject<IGFunnelChartThemeDefinition>
@end

/*!
 Dark theme for the funnel chart.
 */
@interface IGFunnelChartDarkTheme1 : NSObject<IGFunnelChartThemeDefinition>
@end

/*!
 Dark theme for the funnel chart.
 */
@interface IGFunnelChartDarkTheme2 : NSObject<IGFunnelChartThemeDefinition>
@end

/*!
 Dark theme for the funnel chart.
 */
@interface IGFunnelChartDarkTheme3 : NSObject<IGFunnelChartThemeDefinition>
@end

/*!
 Dark theme for the funnel chart.
 */
@interface IGFunnelChartDarkTheme4 : NSObject<IGFunnelChartThemeDefinition>
@end

/*!
 Infragistics gradient theme for the funnel chart.
 */
//@interface IGFunnelChartIGThemeGradient : NSObject<IGFunnelChartThemeDefinition>
//@end

/*!
 Infragistics dark gradient theme for the funnel chart.
 */
//@interface IGFunnelChartIGThemeDarkGradient : NSObject<IGFunnelChartThemeDefinition>
//@end

/*!
 Finance gradient theme for the funnel chart.
 */
//@interface IGFunnelChartFinanceTheme1 : NSObject<IGFunnelChartThemeDefinition>
//@end

/*!
 Finance gradient theme for the funnel chart.
 */
//@interface IGFunnelChartFinanceTheme2 : NSObject<IGFunnelChartThemeDefinition>
//@end

/*!
 Finance gradient theme for the funnel chart.
 */
//@interface IGFunnelChartFinanceTheme3 : NSObject<IGFunnelChartThemeDefinition>
//@end

/*!
 Finance gradient theme for the funnel chart.
 */
//@interface IGFunnelChartFinanceTheme4 : NSObject<IGFunnelChartThemeDefinition>
//@end

/*!
 Finance gradient theme for the funnel chart.
 */
//@interface IGFunnelChartFinanceTheme5 : NSObject<IGFunnelChartThemeDefinition>
//@end

/*!
 A default theme based on a lighter color scheme.
 */
@interface IGGaugeThemeLight : NSObject<IGGaugeThemeDefinition>
@end
/*!
 A default theme based on a darker color scheme.
 */
@interface IGGaugeThemeDark : NSObject<IGGaugeThemeDefinition>
@end


/*!
 Default sparkline theme.
 */
@interface IGSparklineViewDefaultTheme : NSObject<IGSparklineThemeDefinition>
@end
/*!
 A default theme based on a lighter color scheme.
 */
@interface IGSparklineViewLightTheme1 : NSObject<IGSparklineThemeDefinition>
@end
@interface IGSparklineViewLightTheme2 : NSObject<IGSparklineThemeDefinition>
@end
@interface IGSparklineViewLightTheme3 : NSObject<IGSparklineThemeDefinition>
@end
@interface IGSparklineViewLightTheme4 : NSObject<IGSparklineThemeDefinition>
@end
/*!
 A default theme based on a darker color scheme.
 */
@interface IGSparklineViewDarkTheme1 : NSObject<IGSparklineThemeDefinition>
@end
@interface IGSparklineViewDarkTheme2 : NSObject<IGSparklineThemeDefinition>
@end
@interface IGSparklineViewDarkTheme3 : NSObject<IGSparklineThemeDefinition>
@end
@interface IGSparklineViewDarkTheme4 : NSObject<IGSparklineThemeDefinition>
@end

@interface IGSparklineFinance1Theme: NSObject<IGSparklineThemeDefinition>
@end

/* A default theme for the BulletGraph*/
@interface IGBulletGraphViewDefaultTheme : NSObject<IGBulletGraphThemeDefinition>
@end

@interface IGBulletGraphViewLightTheme1 :  NSObject<IGBulletGraphThemeDefinition>
@end
@interface IGBulletGraphViewLightTheme2 :  NSObject<IGBulletGraphThemeDefinition>
@end
@interface IGBulletGraphViewLightTheme3 :  NSObject<IGBulletGraphThemeDefinition>
@end
@interface IGBulletGraphViewLightTheme4 :  NSObject<IGBulletGraphThemeDefinition>
@end
@interface IGBulletGraphViewDarkTheme1 :  NSObject<IGBulletGraphThemeDefinition>
@end
@interface IGBulletGraphViewDarkTheme2 :  NSObject<IGBulletGraphThemeDefinition>
@end
@interface IGBulletGraphViewDarkTheme3 :  NSObject<IGBulletGraphThemeDefinition>
@end
@interface IGBulletGraphViewDarkTheme4 :  NSObject<IGBulletGraphThemeDefinition>
@end



/*!
Light theme for linear gauge.
*/
@interface IGLinearGaugeLightTheme : NSObject<IGLinearGaugeThemeDefinition>
@end

/*!
Dark variant of the light linear gauge theme.
 */
@interface IGLinearGaugeDarkTheme : NSObject<IGLinearGaugeThemeDefinition>
@end

@interface IGGRangeSelectorBaseTheme: NSObject<IGRangeSelectorThemeDefinition>
@property (readonly) UIColor* minMaxBorderColor;
@property (readonly) UIColor* minMaxBackgroundColor;
@end

@interface IGRangeSelectorTheme1 :IGGRangeSelectorBaseTheme
@end
@interface IGRangeSelectorTheme2 :IGGRangeSelectorBaseTheme
@end
@interface IGRangeSelectorTheme3 : IGGRangeSelectorBaseTheme
@end
@interface IGRangeSelectorTheme4 :IGGRangeSelectorBaseTheme
@end
@interface IGRangeSelectorTheme5 : IGGRangeSelectorBaseTheme
@end
@interface IGRangeSelectorTheme6 : IGGRangeSelectorBaseTheme
@end
@interface IGRangeSelectorTheme7: IGGRangeSelectorBaseTheme
@end
@interface IGRangeSelectorTheme8 :IGGRangeSelectorBaseTheme
@end
@interface IGRangeSelectorTheme9 : IGGRangeSelectorBaseTheme
@end
@interface IGRangeSelectorTheme10 :IGGRangeSelectorBaseTheme
@end
@interface IGRangeSelectorTheme11 : IGGRangeSelectorBaseTheme
@end
@interface IGRangeSelectorTheme12 : IGGRangeSelectorBaseTheme
@end
@interface IGRangeSelectorTheme13 : IGGRangeSelectorBaseTheme
@end
@interface IGRangeSelectorTheme14 :IGGRangeSelectorBaseTheme
@end