#import <UIKit/UIKit.h>
#import "Core.h"
#import "Enums.h"
#import "Themes.h"
#import "IGLinearGaugeRange.h"
#import "VisualChartData.h"

@class IGLinearGaugeView;

/*! This protocol has methods that provide the ability to interact with the linear gauge.
 */
@protocol IGLinearGaugeViewDelegate <NSObject>
@optional
/** This method allows the user to supply an NSString that formats the label value that appears on the scale of the linear gauge.
 @param linearGaugeView Reference to the linear gauge.
 @param labelValue The scale value currently being processed for a label.
 @return Returns the string that will represent the supplied labelValue on the linear gauge scale.
 */
-(NSString *)linearGaugeView:(IGLinearGaugeView *)linearGaugeView formatStringForValue:(double)labelValue;
@end

/*!
 IGLinearGaugeView is a data visualization control, capable of displaying a linear gauge. It contains a number of visual elements, such as a scale with tickmarks and labels, a needle and a number of ranges. A scale is created by supplying minimumValue and maximumValue and a needle is created by setting value property. The needle can be set to any of the predefined shapes. The linear gauge also supports ranges, which provide visual cues for the scale. Additionally, the gauge has a backing shape. This shape is drawn behind the scale and acts as a background for the gauge.
 */
@interface IGLinearGaugeView : UIView
{
    UIControl *_container;
    NSMutableArray *_ranges;
    NSMutableArray *_rangeBrushes, *_rangeOutlines;

    UIColor *_backgroundColor;
}

///----------------------
///@name Configuring the Linear Gauge
///----------------------

/** Sets the interaction delegate for the linear gauge.
 */
@property (nonatomic, assign) id<IGLinearGaugeViewDelegate> delegate;

/** The font used by the scale labels.
 */
@property (nonatomic, retain) UIFont *font;

/** The font brush used by the scale labels.
 */
@property (nonatomic, retain) IGBrush *fontBrush;

/** The interval used by the scale.
 */
@property(nonatomic) double interval;

/* The maximum value of the scale.
*/
@property (nonatomic, assign) double maximumValue;

/* The minimum value of the scale.
*/
@property (nonatomic, assign) double minimumValue;

/** The orientation of the scale.
*/
@property (nonatomic, assign) IGLinearScaleOrientation orientation;

/** An object that defines a set of brushes and fonts that will be used to style the linear gauge.
 */
@property (nonatomic, assign) id<IGLinearGaugeThemeDefinition> theme;

/** The number of seconds over which the linear gauge should be animated.
 */
@property (nonatomic, assign) NSTimeInterval transitionDuration;

/** The value, at which to point the needle of the linear gauge.
 */
@property (nonatomic, assign) double value;

///----------------------
///@name Backing
///----------------------

/** The brush used to fill the backing of the linear gauge.
 */
@property (nonatomic, retain) IGBrush *backingBrush;

/** The inner extent of the linear gauge backing. This applies only when using fitted backing shapes.
 */
@property (nonatomic, assign) double backingInnerExtent;

/** The outer extent of the linear gauge backing. This applies only when using fitted backing shapes.
 */
@property (nonatomic, assign) double backingOuterExtent;

/** The brush used for the outline of the backing.
 */
@property (nonatomic, retain) IGBrush *backingOutline;

/** The stroke thickness for the backing outline.
 */
@property (nonatomic, assign) double backingStrokeThickness;

///----------------------
///@name Major Tickmarks
///----------------------

/** The brush of major tickmarks. In order to change the brush of the minor tickmarks, use the minorTickBrush property.
 */
@property (nonatomic, retain) IGBrush *tickBrush;

/** The end position of major tickmarks measured from the side of the linear gauge containing the maximumValue.

The value of this property should be between 0 and 1 and affects major tickmarks only. To change the extent of minor tickmarks, use minorTickEndExtent.

 */
@property (nonatomic, assign) double tickEndExtent;

/** A value to start adding tickmarks, added to the scale's minimumValue.
*/
@property(nonatomic) double ticksPostInitial;

/** A value to stop adding tickmarks, subtracted from the scale's maximumValue.
*/
@property(nonatomic) double ticksPreTerminal;

/** The start position of major tickmarks measured from the side of the linear gauge containing the minimumValue.

The value of this property should be between 0 and 1 and affects major tickmarks only. To change the extent of minor tickmarks, use minorTickStartExtent.

 */
@property (nonatomic, assign) double tickStartExtent;

/** The stroke thickness of the major tickmarks.
 */
@property(nonatomic, assign) double tickStrokeThickness;

///----------------------
///@name Minor Tickmarks
///----------------------

/** The position at which to stop rendering the minor tickmarks as a value from 0 to 1, measured from the front/bottom of the linear gauge.

Values further greater than 1 can be used to make this extend further than the normal size of the linear gauge.

 */
@property(nonatomic, assign) double minorTickEndExtent;

/** The position at which to start rendering the minor tickmarks as a value from 0 to 1, measured from the front/bottom of the linear gauge.

Values greater than 1 can be used to make this extend further than the normal radius of the linear gauge.

 */
@property(nonatomic, assign) double minorTickStartExtent;

/** The thickness of minor tickmarks.
 */
@property(nonatomic, assign) double minorTickStrokeThickness;

/** The brush used for the minor tickmarks.
 */
@property (nonatomic, retain) IGBrush *minorTickBrush;

/** The number of tickmarks to place between two major tickmarks.
 */
@property (nonatomic, assign) double minorTickCount;

///----------------------
///@name Needle
///----------------------

/** The brush of the linear gauge needle.
 */
@property (nonatomic, retain) IGBrush *needleBrush;

/** The width of the needle's inner base.
*/
@property (nonatomic) double needleInnerBaseWidth;

/** The position at which to start rendering the needle geometry as a value from 0 to 1, measured from the front/bottom of the linear gauge.

Values further greater than 1 can be used to make this extend further than the normal size of the linear gauge.

*/
@property (nonatomic, assign) double needleInnerExtent;

/** The extent of the needle's inner point.
*/
@property (nonatomic) double needleInnerPointExtent;

/** The width of the needle's inner point.
*/
@property (nonatomic) double needleInnerPointWidth;

/** The width of the needle's outer base.
*/
@property (nonatomic) double needleOuterBaseWidth;

/** The position at which to stop rendering the needle geometry as a value from 0 to 1, measured from the front/bottom of the linear gauge.

Values further greater than 1 can be used to make this extend further than the normal size of the linear gauge.

*/
@property (nonatomic, assign) double needleOuterExtent;

/** The extent of the needle's outer point.
*/
@property (nonatomic) double needleOuterPointExtent;

/** The width of the needle's outer point.
*/
@property (nonatomic) double needleOuterPointWidth;

/** The brush used by the outline of the needle.
 */
@property (nonatomic, retain) IGBrush *needleOutline;

/** The shape to use when rendering the needle from a number of options.
*/
@property(nonatomic, assign) IGLinearGraphNeedleShape needleShape;

/** The stroke thickness of the needle's outline.
 */
@property (nonatomic, assign) double needleStrokeThickness;

///----------------------
///@name Scale
///----------------------

/** A value indicating whether the scale is inverted.

When the scale is inverted the direction in which the scale values increase is right to left.

*/
@property (nonatomic, assign) BOOL isScaleInverted;

/** The brush used to fill the background of the scale.
 */
@property (nonatomic, retain) IGBrush *scaleBrush;

/** The position at which to stop rendering the scale as a value from 0 to 1, measured from the front/bottom of the linear gauge.

Values further greater than 1 can be used to make this extend further than the normal size of the linear gauge.

*/
@property (nonatomic, assign) double scaleEndExtent;

/** The position at which to start rendering the ranges as a value from 0 to 1, measured from the front/bottom of the control.

Values further greater than 1 can be used to make this extend further than the normal size of the linear gauge.

*/
@property (nonatomic, assign) double scaleInnerExtent;

/** The position at which to stop rendering the scale as a value from 0 to 1, measured from the front/bottom of the linear gauge.

Values further greater than 1 can be used to make this extend further than the normal size of the linear gauge.

*/
@property (nonatomic, assign) double scaleOuterExtent;

/** The brush to use for the outline of the scale.
*/
@property (nonatomic, retain) IGBrush *scaleOutline;

/** The position at which to start rendering the scale as a value from 0 to 1, measured from the front/bottom of the linear gauge.

Values further greater than 1 can be used to make this extend further than the normal size of the linear gauge.

*/
@property (nonatomic, assign) double scaleStartExtent;

/** The stroke thickness of the scale outline.
*/
@property (nonatomic, assign) double scaleStrokeThickness;

///----------------------
///@name Scale Labels
///----------------------

/** The position at which to put the labels as a value from 0 to 1, measured from the bottom of the scale.

Values further greater than 1 can be used to make this extend further than the normal size of the linear gauge.

*/
@property (nonatomic, assign) double labelExtent;

/** The interval to use for rendering labels. This defaults to be the same interval as the tickmarks on the scale.
*/
@property (nonatomic, assign) double labelInterval;

/** A value to start adding labels, added to the scale's minimumValue.
*/
@property (nonatomic, assign) double labelsPostInitial;

/** A value to stop adding labels, subtracted from the scale's maximumValue.
*/
@property (nonatomic, assign) double labelsPreTerminal;

///----------------------
///@name Ranges
///----------------------

/** Adds a range to the linear gauge view.

@param range Range to be added to the linear gauge view.

 */
-(void)addRange:(IGLinearGaugeRange *)range;

/** Removes all ranges from the gauge view.
 */
-(void)clearRanges;

/** Inserts a range into a linear gauge view at a specified index.

 @param range Range to be inserted into the linear gauge view.
 @param index Index at which the range will be inserted.

 */
-(void)insertRange:(IGLinearGaugeRange *)range atIndex:(NSUInteger)index;

/** The brush palette used by the linear gauge ranges.
 */
@property (nonatomic, retain) NSArray *rangeBrushes;


@property (nonatomic, assign) double rangeInnerExtent;


@property (nonatomic, assign) double rangeOuterExtent;

/** The brush palette used by the gauge range outlines.
 */
@property (nonatomic, retain) NSArray *rangeOutlines;

/** Returns an array of ranges in the current linear gauge.
 */
@property (nonatomic, readonly) NSArray *ranges;

/** Removes a specified range from the linear gauge view.

@param range Range to be removed from the linear gauge view.

 */
-(void)removeRange:(IGLinearGaugeRange *)range;

///----------------------
///@name Interacting with the Linear Gauge
///----------------------

/** Returns whether the needle exists at a specified point.

@param point A location inside of the linear gauge.
*/
-(BOOL)needleAtPoint:(CGPoint)point;

/** Given a point on the linear gauge view, a value is returned.

Note: If a point is given where there is an no valid value, a value less than the minimumValue will be returned.

@param point A location inside of the linear gauge.

*/
-(double)valueForPoint:(CGPoint)point;

/** Returns a data representation of the visuals of the linear gauge.

This method is available to provide a way to do validation for testing of the visuals of the linear gauge.

 */
-(VisualLinearGaugeData *)exportVisualData;

@end