#import <Foundation/Foundation.h>
#import "IGTreemapView.h"
#import "IGTreemapViewDataSource.h"

@class IGTreemapView;
@class IGTreemapNode;

/*!
 This is the helper class that will create a hierarchical tree of nodes from a given data object.
 The data supplied to the helper is typically a custom business object containing various properties and an array of other business objects.
 The nodes at each level of the treemap can be bound to a numeric property for the nodes' values and a string property for the nodes' labels.
 
 This helper allows to create treemap nodes one level at a time. Each level is created based on a value path, label path and a childSourcePath.
 Value and label path properties are used to set the node's value and label. ChildSourcePath is the name of the array property that contains the node's children. 
 Having a valid childSourcePath doesn't necessarily make the node create its children, but prepares the node's data context if the children need to be created in the future.
 */
@interface IGTreemapViewDataSourceHelper : NSObject<IGTreemapViewDataSource>
{
    IGTreemapNode *_root;
    __weak IGTreemapView *_treemapView;
    NSObject *_data;
    NSMutableArray *_levelInfos;
}

/** Reference to the data model used to populate the treemap view.
 */
@property (nonatomic, retain) NSObject *data;

/** Reference to the treemap view.
 */
@property (nonatomic, weak) IGTreemapView *treemapView;

///----------------------
///@name Initializing the datasource helper
///----------------------

/** Creates a new instance of the data source helper with data and the treemap reference.
 @param data Data model used to populate the treemap.
 @param treemapView Reference to the treemap view.
 */
-(id)initWithData:(NSObject*)data treemapView:(IGTreemapView*)treemapView;

/** Creates a new level of child nodes in the treemap.
 @param valuePath Numeric property name that will be used for the nodes' values.
 @param labelPath String property name that will be used for the nodes' labels.
 @param childSourcePath Array property name that will be used for the nodes' children.
 */
-(void)addLevelWithValuePath:(NSString*)valuePath labelPath:(NSString*)labelPath childSourcePath:(NSString*)childSourcePath;

/** Updates node information at a given level.
 This method can be used to change the values and labels of the treemap nodes at a given level of depth.
 The treemap needs to call its refresh method for the visuals to update.
 @param valuePath New property name to use for the nodes' values.
 @param labelPath New property name to use for the nodes' labels.
 @param level Level of depth, at which the nodes will be changed.
 */
-(void)setValuePath:(NSString*)valuePath labelPath:(NSString*)labelPath forLevel:(NSInteger)level;

/** Adds a new node to the treemap.
 This method should be used to add new nodes to the treemap after a new data object has been added to the hierarchy. Note that this method will not automatically create child nodes. This method must be called for each added data object and for each added sub object.
 @param dataItem A new data object that was added to the underlying data hierarchy.
 @param parent Parent object containing the dataItem parameter. If parent param in nil, the node will be added to the root.
 */
-(void)addData:(NSObject*)dataItem parent:(NSObject*)parent;

/** Inserts a new node to the treemap at a specified index.
 This method should be used to insert new nodes to the treemap after a new data object has been inserted into the hierarchy. Note that this method will not automatically create child nodes. This method must be called for each added data object and for each added sub object.
 @param dataItem A new data object that was added to the underlying data hierarchy.
 @param parent Parent object containing the dataItem parameter. If parent param in nil, the node will be added to the root.
 */
-(void)insertData:(NSObject*)dataItem index:(NSInteger)index parent:(NSObject*)parent;

/** Replaces an existing node with a new one.
 This method should be used to replace an existing node representing oldData parameter. Note that this method will not automatically create child nodes if the new data object has children. addData or insertData methods should be used for each subitem of the new data object.
 @param dataItem A new data object that replaced the old data object.
 @param oldData The old data object that was replaced.
 */
-(void)replaceWithData:(NSObject*)dataItem oldData:(NSObject*)oldData;

/** Replaces an existing node with a new one at a specified index.
 This method should be used to replace an existing node at a specified index. Note that this method will not automatically create child nodes if the new data object has children. addData or insertData methods should be used for each subitem of the new data object.
 @param dataItem A new data object that replaced the old data object.
 @param index Index, at which the data was replaced.
 @param parent The data object containing the object that was replaced.
 */
-(void)replaceWithData:(NSObject*)dataItem index:(NSInteger)index parent:(NSObject*)parent;

/** Removes an existing node based on a given data object.
 @param dataItem The data object that was removed from the hierarchy.
 */
-(void)removeData:(NSObject*)dataItem;

/** Removes an existing node at a specified index.
 @param index Index, at which to remove a node.
 @param parent The data object containing the object that was removed.
 */
-(void)removeDataAtIndex:(NSInteger)index parent:(NSObject*)parent;
@end


/*!
 This class stores information about the property paths associated with different depth levels of the treemap view.
 */
@interface TreemapNodeLevelInfo : NSObject

/** Determines the value property, from which the nodes get their values.
 */
@property (nonatomic, copy) NSString *valuePath;

/** Determines the label property, from which the nodes get their labels.
 */
@property (nonatomic, copy) NSString *labelPath;

/** Determines the property used to create subnodes.
 */
@property (nonatomic, copy) NSString *childSourcePath;
@end
