#import <Foundation/Foundation.h>

@class IGTreemapView;
@class IGTreemapNode;

/*! This protocol must be implemented by any interface that will be used as the datasource for the treemap view. 
 The job of a treemap datasource is to create the initial tree node structure and set the links between the treemap view and the treemap nodes.
 */
@protocol IGTreemapViewDataSource <NSObject>
@required

/** Asks to provide the initial root node for the treemap view.
 @param treemapView Reference to the treemap view.
 @param source Data structure used to create the nodes.
 @return The treemap node that will be the root node.
 */
-(IGTreemapNode*)treemapView:(IGTreemapView*)treemapView provideRootNodeWithSource:(NSObject*)source;

/** Returns the data structure used to populate the treemap.
 @param treemapView Reference to the treemap view.
 */
-(NSObject*)provideSourceForTreemapView:(IGTreemapView*)treemapView;
@end