#import <Foundation/Foundation.h>
#import <CoreGraphics/CoreGraphics.h>
#import <UIKit/UIKit.h>
#import "Core.h"
#import "Enums.h"
#import "Themes.h"
#import "IGLinearGaugeRange.h"
#import "VisualChartData.h"

@class IGBulletGraphView;

/*! This protocol has methods that provide the ability to interact with the bullet graph.
 */
@protocol IGBulletGraphViewDelegate <NSObject>
@optional
/** This method allows the user to supply an NSString that formats the label value that appears on the scale of the bullet graph.
 @param bulletGraphView Reference to the bullet graph.
 @param labelValue The scale value currently being processed for a label.
 @return Returns the string that will represent the supplied labelValue on the bullet graph scale.
 */
-(NSString *)bulletGraphView:(IGBulletGraphView *)bulletGraphView formatStringForValue:(double)labelValue;
@end

/*
 The IGBulletGraphView is a simple single column/bar graph used to display data in a simple manner.   It is designed to set up quickly with just a minimum value, a maximum value, and a value to display.
 */
@interface IGBulletGraphView : UIView
/** Sets the interaction delegate for the bullet graph.
 */
@property (nonatomic, assign) id<IGBulletGraphViewDelegate> delegate;

/*
 Gets or sets a singular value for the IGBulletGraphView.  This value should be 
 between the minimum and maximum value for the control. 
 */
@property (nonatomic)double value;

/*
 Gets or sets the IGBrush that will be applied to the value representation.
 */
@property (nonatomic, retain) IGBrush* valueBrush;

/*
Gets or sets the position at which to start rendering the actual value geometries, measured from the front/bottom of the bullet graph as a value from 0 to 1. Values further from zero than 1 can be used to make this extend further than the normal size of the bullet graph.
*/
@property (nonatomic)double valueInnerExtent;

/* 
 A string property to identify the value object.
 */
@property (nonatomic,retain)NSString* valueName;

/*
 Gets or sets the position at which to stope rendering the value geometries as a value from 0 to 1 measured from the front/bottom.  Values further from zero than 1 can be used to make this extent further than the normal size of the bullet graph.
 */
@property (nonatomic) double valueOuterExtent;

/*
 Gets or sets the IGBrush which will be used to draw an outline around the value bar.  This property is used in conjection with the valueStrokeThickness property.
 */
@property (nonatomic,retain)IGBrush* valueOutline;

/*
 Gets or sets the thickness of the border which will be drawn around the value bar.  
 */
@property(nonatomic)double valueStrokeThickness;

/*
 Gets or sets the IGBrush which will be applied to background of the control drawing area.
 */
@property(nonatomic,retain)IGBrush* backingBrush;

/*Gets or sets the inner extent of the bullet graph backing.  */
@property(nonatomic)double backingInnerExtent;

/*Gets or sets the outer extent of the bullet graph backing.  */
@property(nonatomic)double backingOuterExtent;

/*
 Gets or sets the IGBrush which will be applied to the outline of the backing area.
 */
@property(nonatomic,retain)IGBrush* backingOutline;

/*
 Gets or sets the thickness of the border which will be drawn along the backing area of the control.
 */
@property(nonatomic)double backingStrokeThickness;

/** Determines the font used by the gauge scale labels.
 */
@property (nonatomic, retain) UIFont *font;

/** Determines the font brush used by the BulletGraph scale labels.
 */
@property (nonatomic, retain) IGBrush *fontBrush;

/** Determines the interval used by the scale.
 */
@property (nonatomic) CGFloat interval;

/* Gets or sets how the control will render under the given orientation.  By default, if the BulletGraph is horizontal in orientation, the bar will draw left to right.  If set to true, the bar and scale will be drawn right to left.
 */
@property(nonatomic)BOOL isScaleInverted;

/*
 Gets or sets the position at whichto put the labels as a value of 0 to 1, measured from the bottom of the scale.  Values further from zero than 1 can be used to make this extend further than the normal size of the bullet graph.
 */
@property(nonatomic)double labelExtent;

@property(nonatomic)double labelInterval;

/* A value to start adding labels to the scale, added to the scale's MinimumValue. */
@property(nonatomic)double labelsPostInitial;

/* A value to stop rendering label to the scale, subtracting from the MaximumValue. */
@property(nonatomic)double labelsPreTerminal;

/** Determines the maximum value of the scale.
 */
@property (nonatomic) double maximumValue;

/** Determines the minimum value of the scale.
 */
@property (nonatomic) double minimumValue;

/*
 The IGBrush which will be applied to the minor ticks.
 */
@property (nonatomic,retain) IGBrush* minorTickBrush;

/* The number of minor ticks which will be rendered between each major tick line.*/
@property(nonatomic)NSInteger minorTickCount;

/*
 Gets or sets the position at which to stop rendering the minor tickmarks as a value from 0 to 1, measured from the front / bottom of the bullet graph.  Values further from zero than 1 can be used to make this extend further than the normal size fo the bullet graph.
 */
@property(nonatomic)double minorTickEndExtent;

/*
 Gets or sets the position at which to start rendering the minor tickmarks as a value from 0 to 1, measured from the front / bottom of the bullet graph.  Values further from zero than 1 can be used to make this extend further than the normal size fo the bullet graph.
 */
@property(nonatomic)double minorTickStartExtent;

/*
 Gets or sets the tickness of the minor tick lines.
 */
@property(nonatomic)double minorTickStrokeThickness;

/*
 Gets/sets if the control should display vertically or horizontally.  
 */
@property (nonatomic)IGOrientation orientation;

/*
 Gets / sets the collection of IGBrush objects which will be applied to the ranges.  This is used instead of setting the brush directly on the range object.
 */
@property (nonatomic,retain)NSArray* rangeBrushes;

/*
 Gets or sets the position at which to start rendering the ranges, measured from the front / bottom as a value from 0 to 1.  Values further from zero than 1 can be used to make this extend further than the normal size fo the bullet graph.
 */
@property(nonatomic)double rangeInnerExtent;
/*
 Gets or sets the position at which to stop rendering the ranges, measured from the front / bottom as a value from 0 to 1.  Values further from zero than 1 can be used to make this extend further than the normal size fo the bullet graph.
 */
@property(nonatomic)double rangeOuterExtent;

/*
 Gets / sets the collection of IGBrush objects which will be applied to the range's outline.  This is used instead of setting the brush directly on the range object.
 */
@property(nonatomic,retain)NSArray* rangeOutlines;

/*
 Gets the current range collection which will be displayed on the bullet graph.  To modify this collection use the addRange, clearRanges, and removeRange methods.
 */
@property(nonatomic,readonly)NSArray* ranges;

/*
 Gets or sets the position at which to stop rendering the scale, measured from the front / bottom as a value from 0 to 1.  Values further from zero than 1 can be used to make this extend further than the normal size fo the bullet graph.
 */
@property(nonatomic)double scaleEndExtent;
/*
 Gets or sets the position at which to start rendering the scale, measured from the front / bottom as a value from 0 to 1.  Values further from zero than 1 can be used to make this extend further than the normal size fo the bullet graph.
 */
@property(nonatomic)double scaleStartExtent;

/*
 Get / sets the targetValue which should be displayed on the control.  When set, a marker will appear on the bullet graph.
 */
@property (nonatomic)double targetValue;

/*
 Get / sets the width of the target value marker on the bullet graph.
 */
@property (nonatomic)double targetValueBreadth;

/*
 The IGBrush which will be used to color the targetValue marker.
 */
@property (nonatomic,retain)IGBrush* targetValueBrush;

/*
 Gets or sets the position at which to start rendering the targetValue marker, measured from the front / bottom as a value from 0 to 1.  Values further from zero than 1 can be used to make this extend further than the normal size fo the bullet graph.
 */
@property (nonatomic)double targetValueInnerExtent;
/*
 Gets or sets the position at which to stop rendering the targetValue marker, measured from the front / bottom as a value from 0 to 1.  Values further from zero than 1 can be used to make this extend further than the normal size fo the bullet graph.
 */
@property (nonatomic)double targetValueOuterExtent;

/*
 The IGBrush which will be used to draw the outline of the targetValue marker.
 */
@property(nonatomic,retain)IGBrush* targetValueOutline;

/* The thickness of the border which will be used to draw the border around the target value marker.*/
@property (nonatomic)double targetValueStrokeThickness;

/*
 The IGBrush which will be applied to the tickMarks of the BulletGraph.
 */
@property(nonatomic,retain)IGBrush* tickBrush;
/*
 Gets or sets the position at which to end rendering the tickMarks, measured from the front / bottom as a value from 0 to 1.  Values further from zero than 1 can be used to make this extend further than the normal size fo the bullet graph.
 */
@property (nonatomic)double tickEndExtent;

/*
 A value to start adding tickmarks, added to the scale minimum value.
 */
@property (nonatomic)double ticksPostInitial;

/*
 A value to stop adding tickmarks, subtracted from the scale maximum Value.
 */
@property (nonatomic)double ticksPreTerminal;
/*
 Gets or sets the position at which to start rendering the tickMarks, measured from the front / bottom as a value from 0 to 1.  Values further from zero than 1 can be used to make this extend further than the normal size fo the bullet graph.
 */
@property (nonatomic)double tickStartExtent;

/*
 The thickness that the tickmarks will be drawn.
 */
@property (nonatomic)double tickStrokeThickness;

@property (nonatomic)NSInteger transitionDuration;


/** An object that defines a set of brushes and fonts that will be used to style the IGBulletGraph.
 */
@property (nonatomic, assign) id<IGBulletGraphThemeDefinition> theme;


/** Removes all ranges from the gauge view.
 */
-(void)clearRanges;

/** Adds a range to the gauge view.
 @param range Range to be added to the gauge view.
 */
-(void)addRange:(IGLinearGaugeRange*)range;

/** Inserts a range into a gauge view at a specified index.
 @param range Range to be inserted into a gauge view.
 @param index Index at which the range will be inserted.
 */
-(void)insertRange:(IGLinearGaugeRange*)range atIndex:(NSInteger)index;

/** Removes a specified range from the gauge view.
 @param range Range to be removed from the gauge view.
 */
-(void)removeRange:(IGLinearGaugeRange*)range;

/** Returns a data representation of the visuals of the gauge.
 
 This method is available to provide a way to do validation for testing of the visuals of the gauge.
 */
- (VisualBulletChartData*)exportVisualData;


@end
