#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "Core.h"
#import "IGTreemapNode.h"

@class IGBrush;
@class IGTreemapNode;

/*!
 This interface represents a color scale used to fill treemap nodes. Each treemap node has a reference to the custom object that it was created from. 
 The color mapper uses propertyPath property to get a mapping value that will be used to determine the fill of the node. 
 Minimum and maximum of the mapper are automatically calculated from the underlying data, but can be manually set to a custom range. To set the range back to automatic, minimum and maximum properties should be set to NAN.
 */
@interface IGTreemapNodeColorMapper : NSObject
{
    CGFloat _minimum, _maximum;
    CGFloat _resolvedMinimum;
    CGFloat _resolvedMaximum;
    IGBrush *_from, *_to;
    NSString *_propertyPath;
}

/** Gets the reference to the treemap view. (read-only)
 */
@property (nonatomic, readonly) IGTreemapView *treemapView;

/** Specifies the minimum value of the color mapper.
 */
@property (nonatomic) CGFloat minimum;

/** Specifies the maximum value of the color mapper.
 */
@property (nonatomic) CGFloat maximum;

/** Specifies the start brush of the color mapper.
 */
@property (nonatomic, retain) IGBrush *from;

/** Specifies the end brush of the color mapper.
 */
@property (nonatomic, retain) IGBrush *to;

/** Returns the actual minimum value of the mapper. (read-only)
 This property resolves to the auto-calculated minimum if the minimum property was not explicitly set.
 */
@property (nonatomic, readonly) CGFloat resolvedMinimum;

/** Returns the actual maximum value of the mapper. (read-only)
 This property resolves to the auto-calculated maximum if the maximum property was not explicitly set.
 */
@property (nonatomic, readonly) CGFloat resolvedMaximum;

/** Specifies the name of a numeric property for mapping.
 This is a property on the business object that was used to create a treemap node. 
 Values of this property will be mapped using min and max values to come up with a node brush.
 */
@property (nonatomic, copy) NSString *propertyPath;

/** Returns a mapped brush for a given node.
 */
-(IGBrush*)mapColorForNode:(IGTreemapNode*)node;
@end
